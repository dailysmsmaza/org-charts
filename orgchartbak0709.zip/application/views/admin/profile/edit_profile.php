<div class="maincontentarea smootheffect">
    <div class="pageconent">
        <div class="pageconentbx">
              <div class="pageheding">
                  <h2><?php echo $heading_title; ?></h2>              
              </div>
              <?php if (validation_errors()) { ?>
                        <div class="alert alert-danger">
                            <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                            <strong><i class="fa fa-times-circle" aria-hidden="true"></i></i></strong> <?php echo validation_errors(); ?>
                        </div>
                    <?php } ?>
                    <?php
                        if ($this->session->flashdata("fail")) {
                            ?>
                            <div class="alert alert-danger">
                                <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                                <strong><i class="fa fa-times-circle" aria-hidden="true"></i></i></strong> <?php echo $this->session->flashdata("fail") ?>
                            </div>
                    <?php } ?>
                <?php 
                 /* Get Segment*/
                  $secnond_segment = $this->uri->segment(2);
                ?>
            <div class="whitebox">
                <div class="formwraper">
                    <form method="post" action="<?php echo base_url('login/edit_profile/'.$edit_profile['id']) ?>"  name="userprofile_form" enctype="multipart/form-data">
                        <div class="form-group row">
                            <label class="col-md-3 col-lg-3 col-xl-2">User Image</label>
                            <div class="col-md-9 col-lg-9 col-xl-10 fileprevwrap">
                                <input type="file" name="user_image">
                                <input type="hidden" name="old_user_image" value="<?php echo $edit_profile['user_image'] ?>">
                                <?php 
                                    if(get_themeoption('favicon')!=""){
                                 ?>             
                                <img src="<?php echo ($edit_profile['user_image']!="") ?  base_url('assets/userimage/').$edit_profile['user_image']  : base_url('assets/images/user_demo.png')?>" style="height:100px;">
                               <?php } ?>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-md-3 col-lg-3 col-xl-2">First Name</label>
                            <div class="col-md-9 col-lg-9 col-xl-10"><input type="text" name="first_name" value="<?php echo $edit_profile['first_name'] ?>" class="form-control"></div>
                        </div>
                        <div class="form-group row">
                            <label class="col-md-3 col-lg-3 col-xl-2">Last Name</label>
                            <div class="col-md-9 col-lg-9 col-xl-10"><input type="text" name="last_name" value="<?php echo $edit_profile['last_name'] ?>" class="form-control"></div>
                        </div>                   
                        <div class="form-group row">
                            <label class="col-md-3 col-lg-3 col-xl-2">Email</label>
                            <div class="col-md-9 col-lg-9 col-xl-10"><input type="text" name="email" value="<?php echo $edit_profile['email'] ?>" class="form-control"></div>
                        </div>
                        <div class="form-group row">
                            <label class="col-md-3 col-lg-3 col-xl-2">Password</label>
                            <div class="col-md-9 col-lg-9 col-xl-10"><input type="password" name="password" id="password" class="form-control"></div>
                        </div>
                        <div class="form-group row">
                            <label class="col-md-3 col-lg-3 col-xl-2">Confirm Password</label>
                            <div class="col-md-9 col-lg-9 col-xl-10"><input type="password" name="password"  class="form-control"></div>
                        </div>
                        <div class="form-group row">
                            <label class="col-md-3 col-lg-3 col-xl-2">Phone</label>
                            <div class="col-md-9 col-lg-9 col-xl-10"><input type="text" name="phone" value="<?php echo $edit_profile['phone'] ?>" class="form-control"></div>
                        </div>
                        <?php 
                            if($this->session->userdata("role")==3){
                         ?>
                        <div class="form-group row">
                            <label class="col-md-3 col-lg-3 col-xl-2">Designation</label>
                            <div class="col-md-9 col-lg-9 col-xl-10">
                                <input type="text" name="designation" value="<?php echo $edit_profile['designation'] ?>" class="form-control">
                            </div>
                        </div>
                    <?php } ?>
                        <div class="form-group row">
                            <label class="col-md-3 col-lg-3 col-xl-2">About</label>
                            <div class="col-md-9 col-lg-9 col-xl-10">
                                <textarea name="about" cols="35" rows="5" class="form-control"><?php echo $edit_profile['about'] ?></textarea>
                            </div>
                        </div>
                        <?php 
                            if($this->session->userdata("role")==3){
                         ?>
                        <div class="form-group row">
                            <label class="col-md-3 col-lg-3 col-xl-2">Skill</label>
                            <div class="col-md-9 col-lg-9 col-xl-10">
                                <input type="text" name="skill" value="<?php echo $edit_profile['skill'] ?>" class="form-control">
                            </div>
                        </div>
                    <?php } ?>
                        <div class="form-group row">
                            <label class="col-md-3 col-lg-3 col-xl-2">Address</label>
                            <div class="col-md-9 col-lg-9 col-xl-10">
                                <textarea name="city" class="form-control"><?php echo $edit_profile['city'] ?></textarea>                                
                            </div>
                        </div>                
                        <div class="form-group row">
                            <input type="submit" value="Update User">
                        </div>                              
                </form>
            </div>
            </div>    
        </div>
    </div>
</div>
        
        <?php 
            if($secnond_segment == "edit"){
        ?>
        <script src="<?php echo base_url('assets/js/') ?>jquery-3.2.1.min.js"></script>                 
    <?php } ?>         
<!--Jquery Validation --->
<script type="text/javascript">
    $(function () {
        $("form[name='userprofile_form']").validate({
            //set Validation rules    
            rules: {                      
                company: {required: true},                        
                first_name: {required: true},
                last_name: {required: true},
                user_name: {required: true},
                email: {required: true, email: true},
                //password: {required: true},                   
                phone: {required: true, number: true},
                designation: {required: true},
                //about: {required: true},
                skill: {required: true},
                city: {required: true}
            },
            // Specify validation error messages
            messages: {
                confirmpassword: {equalTo: "Password and Confirm Password Does Not matche"},
            },
            //Add Color To Message
            highlight: function (element) {
                $(element).parent().addClass('error_msg')
            },
            // Make sure the form is submitted to the destination defined
            // in the "action" attribute of the form when valid
            submitHandler: function (form) {
                form.submit();
            }
        });
    });
    setTimeout(function () {
        $(".alert-danger").hide()
    }, 3000);
    setTimeout(function () {
        $(".alert-success").hide()
    }, 3000);
</script>