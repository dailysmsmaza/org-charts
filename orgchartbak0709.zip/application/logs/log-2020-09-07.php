<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-09-07 06:24:23 --> Severity: Warning --> Illegal string offset 'user_id' /home1/gujjucod/public_html/demo/orgchart/application/views/admin/department/add_edit_department.php 150
ERROR - 2020-09-07 06:24:23 --> Severity: Notice --> Uninitialized string offset: 0 /home1/gujjucod/public_html/demo/orgchart/application/views/admin/department/add_edit_department.php 150
ERROR - 2020-09-07 06:24:26 --> Severity: Warning --> Illegal string offset 'user_id' /home1/gujjucod/public_html/demo/orgchart/application/views/admin/department/add_edit_department.php 150
ERROR - 2020-09-07 06:24:26 --> Severity: Notice --> Uninitialized string offset: 0 /home1/gujjucod/public_html/demo/orgchart/application/views/admin/department/add_edit_department.php 150
