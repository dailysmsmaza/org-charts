<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-08-26 07:23:11 --> Severity: Notice --> Undefined variable: error D:\xampp\htdocs\orgchart\application\controllers\Requestfeedback.php 117
ERROR - 2020-08-26 07:23:38 --> Severity: Notice --> Undefined variable: error D:\xampp\htdocs\orgchart\application\controllers\Requestfeedback.php 117
ERROR - 2020-08-26 07:25:07 --> Severity: Notice --> Undefined variable: error D:\xampp\htdocs\orgchart\application\controllers\Requestfeedback.php 117
ERROR - 2020-08-26 07:25:27 --> Severity: Notice --> Undefined variable: error D:\xampp\htdocs\orgchart\application\controllers\Requestfeedback.php 117
ERROR - 2020-08-26 07:26:18 --> Severity: Notice --> Undefined variable: error D:\xampp\htdocs\orgchart\application\controllers\Requestfeedback.php 111
ERROR - 2020-08-26 07:26:58 --> Severity: Notice --> Undefined variable: error D:\xampp\htdocs\orgchart\application\controllers\Requestfeedback.php 111
ERROR - 2020-08-26 07:37:48 --> Severity: Notice --> Undefined index: reqfd_reply D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 64
ERROR - 2020-08-26 07:37:48 --> Severity: Notice --> Undefined index: reqfd_reply D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 64
ERROR - 2020-08-26 07:37:48 --> Severity: Notice --> Undefined index: reqfd_reply D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 64
ERROR - 2020-08-26 07:37:48 --> Severity: Notice --> Undefined index: reqfd_reply D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 64
ERROR - 2020-08-26 07:37:48 --> Severity: Notice --> Undefined index: reqfd_reply D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 64
ERROR - 2020-08-26 07:37:48 --> Severity: Notice --> Undefined index: reqfd_reply D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 64
ERROR - 2020-08-26 07:37:48 --> Severity: Notice --> Undefined index: reqfd_reply D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 64
ERROR - 2020-08-26 07:37:48 --> Severity: Notice --> Undefined index: reqfd_reply D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 64
ERROR - 2020-08-26 07:37:48 --> Severity: Notice --> Undefined index: reqfd_reply D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 64
ERROR - 2020-08-26 07:37:48 --> Severity: Notice --> Undefined index: reqfd_reply D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 64
ERROR - 2020-08-26 07:39:07 --> Severity: Notice --> Undefined variable: error D:\xampp\htdocs\orgchart\application\controllers\Requestfeedback.php 111
ERROR - 2020-08-26 08:00:04 --> Severity: Compile Error --> Cannot redeclare Requestfeedback_model::delete() D:\xampp\htdocs\orgchart\application\models\Requestfeedback_model.php 89
ERROR - 2020-08-26 09:23:27 --> Severity: Notice --> Undefined variable: error D:\xampp\htdocs\orgchart\application\controllers\Requestfeedback.php 128
ERROR - 2020-08-26 09:23:36 --> Severity: Notice --> Undefined variable: error D:\xampp\htdocs\orgchart\application\controllers\Requestfeedback.php 128
ERROR - 2020-08-26 09:26:03 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\orgchart\application\views\admin\feedback\edit_requestfeedback.php 41
ERROR - 2020-08-26 09:26:54 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\orgchart\application\views\admin\feedback\edit_requestfeedback.php 33
ERROR - 2020-08-26 09:28:36 --> Severity: Compile Error --> Cannot use [] for reading D:\xampp\htdocs\orgchart\application\views\admin\feedback\edit_requestfeedback.php 33
ERROR - 2020-08-26 09:28:46 --> Query error: Unknown column 'reqfd_userfrom' in 'field list' - Invalid query: select reqfd_userfrom,id from user_master where id='16'
ERROR - 2020-08-26 09:29:31 --> Query error: Unknown column 'reqfd_userfrom' in 'field list' - Invalid query: select reqfd_userfrom,id from user_master where id='16'
ERROR - 2020-08-26 09:29:37 --> Query error: Unknown column 'reqfd_userfrom' in 'field list' - Invalid query: select reqfd_userfrom,id from user_master where id='16'
ERROR - 2020-08-26 09:31:25 --> Severity: Notice --> Undefined variable: feedbacks_value D:\xampp\htdocs\orgchart\application\views\admin\feedback\edit_requestfeedback.php 28
ERROR - 2020-08-26 09:31:34 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\orgchart\application\views\admin\feedback\edit_requestfeedback.php 49
ERROR - 2020-08-26 09:31:37 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\orgchart\application\views\admin\feedback\edit_requestfeedback.php 49
ERROR - 2020-08-26 09:31:48 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\orgchart\application\views\admin\feedback\edit_requestfeedback.php 49
ERROR - 2020-08-26 09:32:00 --> Severity: Notice --> Undefined offset: 0 D:\xampp\htdocs\orgchart\application\views\admin\feedback\edit_requestfeedback.php 49
ERROR - 2020-08-26 09:43:38 --> Severity: Warning --> mb_detect_encoding() expects parameter 1 to be string, object given D:\xampp\htdocs\orgchart\dompdf\src\Dompdf.php 424
ERROR - 2020-08-26 09:43:38 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\orgchart\dompdf\src\Dompdf.php 428
ERROR - 2020-08-26 09:43:38 --> Severity: Warning --> mb_convert_encoding(): Illegal character encoding specified D:\xampp\htdocs\orgchart\dompdf\src\Dompdf.php 428
ERROR - 2020-08-26 09:43:39 --> Severity: Warning --> mb_detect_encoding() expects parameter 1 to be string, object given D:\xampp\htdocs\orgchart\dompdf\src\Dompdf.php 424
ERROR - 2020-08-26 09:43:39 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\orgchart\dompdf\src\Dompdf.php 428
ERROR - 2020-08-26 09:43:39 --> Severity: Warning --> mb_convert_encoding(): Illegal character encoding specified D:\xampp\htdocs\orgchart\dompdf\src\Dompdf.php 428
ERROR - 2020-08-26 09:55:34 --> Severity: Notice --> Undefined index: company D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 63
ERROR - 2020-08-26 09:55:34 --> Severity: Notice --> Undefined index: company D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 63
ERROR - 2020-08-26 09:55:34 --> Severity: Notice --> Undefined index: company D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 63
ERROR - 2020-08-26 09:55:34 --> Severity: Notice --> Undefined index: company D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 63
ERROR - 2020-08-26 09:55:34 --> Severity: Notice --> Undefined index: company D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 63
ERROR - 2020-08-26 09:55:34 --> Severity: Notice --> Undefined index: company D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 63
ERROR - 2020-08-26 09:55:34 --> Severity: Notice --> Undefined index: company D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 63
ERROR - 2020-08-26 09:55:34 --> Severity: Notice --> Undefined index: company D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 63
ERROR - 2020-08-26 09:55:34 --> Severity: Notice --> Undefined index: company D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 63
ERROR - 2020-08-26 09:55:34 --> Severity: Notice --> Undefined index: company D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 63
ERROR - 2020-08-26 10:01:15 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'reqfd,user_master as umcmp, user_master as umfrom, user_master as umto  where re' at line 1 - Invalid query: select reqfd_id,umcmp.first_name as company_id, umfrom.first_name as reqfd_userfrom,reqfd_subject,reqfd_message,umto.first_name as reqfd_userto,reqfd_status,company_id,reqfd_reply from requestfdbck_master as ras reqfd,user_master as umcmp, user_master as umfrom, user_master as umto  where reqfd.company_id=umcmp.id and reqfd.reqfd_userfrom=umfrom.id and reqfd.reqfd_userto=umto.id 
ERROR - 2020-08-26 11:44:26 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '' at line 1 - Invalid query: select reqfd_id,umcmp.first_name as company_id, umfrom.first_name as reqfd_userfrom,reqfd_subject,reqfd_message,umto.first_name as reqfd_userto,reqfd_status,reqfd_reply from requestfdbck_master as  reqfd,user_master as umcmp, user_master as umfrom, user_master as umto  where reqfd.company_id=umcmp.id and reqfd.reqfd_userfrom=umfrom.id and reqfd.reqfd_userto=umto.id and 
ERROR - 2020-08-26 12:04:19 --> Severity: Warning --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() D:\xampp\htdocs\orgchart\system\libraries\Email.php 1902
ERROR - 2020-08-26 12:04:20 --> Severity: Warning --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() D:\xampp\htdocs\orgchart\system\libraries\Email.php 1902
ERROR - 2020-08-26 12:08:59 --> Severity: Warning --> Illegal string offset 'user_id' D:\xampp\htdocs\orgchart\application\views\admin\department\add_edit_department.php 150
ERROR - 2020-08-26 12:08:59 --> Severity: Notice --> Uninitialized string offset: 0 D:\xampp\htdocs\orgchart\application\views\admin\department\add_edit_department.php 150
ERROR - 2020-08-26 12:29:29 --> Severity: Notice --> Undefined variable: error D:\xampp\htdocs\orgchart\application\controllers\Requestfeedback.php 144
ERROR - 2020-08-26 13:43:19 --> Severity: Warning --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() D:\xampp\htdocs\orgchart\system\libraries\Email.php 1896
ERROR - 2020-08-26 13:43:52 --> Severity: Notice --> Undefined variable: error D:\xampp\htdocs\orgchart\application\controllers\Requestfeedback.php 153
ERROR - 2020-08-26 14:40:13 --> Severity: Notice --> Undefined variable: <!DOCTYPE html PUBLIC '-//W3C//DTD XHTML 1.0 Transitional//EN' 'http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd'><html lang=''><head><meta http-equiv='x-ua-compatible' content='IE=edge'><meta http-equiv='content-type' content='text/html; charset=utf-8'><title>ORG Chart Account Succefully Creation</title><link href='https://fonts.googleapis.com/css?family=Work+Sans:700&amp;display=swap' rel='stylesheet'><style type='text/css'>body{ margin:0;padding:0;background-color:#fafbfc;}</style></head>test descriptionxx D:\xampp\htdocs\orgchart\application\controllers\Requestfeedback.php 125
