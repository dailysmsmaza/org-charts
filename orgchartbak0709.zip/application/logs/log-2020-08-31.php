<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-08-31 00:21:10 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-31 00:21:20 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-31 00:21:46 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-31 00:24:51 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-31 00:41:19 --> Severity: Notice --> Undefined variable: result /home1/gujjucod/public_html/demo/orgchart/application/controllers/Employee.php 168
ERROR - 2020-08-31 00:41:44 --> 404 Page Not Found: Assets/chart
ERROR - 2020-08-31 00:42:15 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-31 00:42:29 --> Severity: Notice --> Undefined variable: result /home1/gujjucod/public_html/demo/orgchart/application/controllers/Employee.php 168
ERROR - 2020-08-31 00:42:29 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-31 00:52:59 --> Severity: Notice --> Undefined variable: result /home1/gujjucod/public_html/demo/orgchart/application/controllers/Employee.php 168
ERROR - 2020-08-31 00:59:43 --> Severity: Notice --> Undefined variable: result /home1/gujjucod/public_html/demo/orgchart/application/controllers/Employee.php 168
ERROR - 2020-08-31 01:04:05 --> Severity: Notice --> Undefined variable: result /home1/gujjucod/public_html/demo/orgchart/application/controllers/Employee.php 168
ERROR - 2020-08-31 01:05:01 --> 404 Page Not Found: Assets/css
