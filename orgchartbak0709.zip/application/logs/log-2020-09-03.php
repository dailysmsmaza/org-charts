<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-09-03 01:05:26 --> Severity: Notice --> Undefined variable: htmleader /home1/gujjucod/public_html/demo/orgchart/application/controllers/Home.php 200
ERROR - 2020-09-03 01:05:26 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home1/gujjucod/public_html/demo/orgchart/system/core/Exceptions.php:271) /home1/gujjucod/public_html/demo/orgchart/system/helpers/url_helper.php 564
ERROR - 2020-09-03 01:17:21 --> Severity: Notice --> Undefined variable: htmleader /home1/gujjucod/public_html/demo/orgchart/application/controllers/Home.php 200
ERROR - 2020-09-03 01:19:34 --> 404 Page Not Found: Assets/images
