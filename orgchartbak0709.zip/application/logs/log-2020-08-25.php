<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-08-25 05:59:36 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '' at line 1 - Invalid query: SELECT * FROM `user_master` where status=1 and role=3 and company=
ERROR - 2020-08-25 05:59:40 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '' at line 1 - Invalid query: SELECT * FROM `user_master` where status=1 and role=3 and company=
ERROR - 2020-08-25 06:34:33 --> Severity: Notice --> Undefined variable: desquery D:\xampp\htdocs\orgchart\application\views\admin\feedback\feedback_list.php 44
ERROR - 2020-08-25 06:34:33 --> Severity: error --> Exception: Call to a member function num_rows() on null D:\xampp\htdocs\orgchart\application\views\admin\feedback\feedback_list.php 44
ERROR - 2020-08-25 06:34:50 --> Severity: Notice --> Undefined variable: desquery D:\xampp\htdocs\orgchart\application\views\admin\feedback\feedback_list.php 44
ERROR - 2020-08-25 06:34:50 --> Severity: error --> Exception: Call to a member function num_rows() on null D:\xampp\htdocs\orgchart\application\views\admin\feedback\feedback_list.php 44
ERROR - 2020-08-25 06:37:00 --> Severity: Notice --> Undefined index: reqfd_userto D:\xampp\htdocs\orgchart\application\views\admin\feedback\feedback_list.php 50
ERROR - 2020-08-25 06:37:00 --> Severity: Notice --> Undefined index: reqfd_userto D:\xampp\htdocs\orgchart\application\views\admin\feedback\feedback_list.php 50
ERROR - 2020-08-25 06:37:00 --> Severity: Notice --> Undefined index: reqfd_userto D:\xampp\htdocs\orgchart\application\views\admin\feedback\feedback_list.php 50
ERROR - 2020-08-25 06:37:00 --> Severity: Notice --> Undefined index: reqfd_userto D:\xampp\htdocs\orgchart\application\views\admin\feedback\feedback_list.php 50
ERROR - 2020-08-25 06:37:00 --> Severity: Notice --> Undefined index: reqfd_userto D:\xampp\htdocs\orgchart\application\views\admin\feedback\feedback_list.php 50
ERROR - 2020-08-25 06:37:00 --> Severity: Notice --> Undefined index: reqfd_userto D:\xampp\htdocs\orgchart\application\views\admin\feedback\feedback_list.php 50
ERROR - 2020-08-25 06:37:00 --> Severity: Notice --> Undefined index: reqfd_userto D:\xampp\htdocs\orgchart\application\views\admin\feedback\feedback_list.php 50
ERROR - 2020-08-25 06:37:00 --> Severity: Notice --> Undefined index: reqfd_userto D:\xampp\htdocs\orgchart\application\views\admin\feedback\feedback_list.php 50
ERROR - 2020-08-25 06:37:00 --> Severity: Notice --> Undefined index: reqfd_userto D:\xampp\htdocs\orgchart\application\views\admin\feedback\feedback_list.php 50
ERROR - 2020-08-25 06:37:00 --> Severity: Notice --> Undefined index: reqfd_userto D:\xampp\htdocs\orgchart\application\views\admin\feedback\feedback_list.php 50
ERROR - 2020-08-25 07:10:11 --> Query error: Unknown column 'id' in 'field list' - Invalid query: select id from requestfdbck_master  where reqfd_status=1
ERROR - 2020-08-25 07:11:11 --> Query error: Unknown column 'id' in 'field list' - Invalid query: select id from requestfdbck_master  where reqfd_status=1
ERROR - 2020-08-25 07:15:18 --> Severity: error --> Exception: syntax error, unexpected '=' D:\xampp\htdocs\orgchart\application\helpers\commonfunction_helper.php 149
ERROR - 2020-08-25 07:15:47 --> Severity: Warning --> A non-numeric value encountered D:\xampp\htdocs\orgchart\application\models\Requestfeedback_model.php 13
ERROR - 2020-08-25 07:19:21 --> Severity: Compile Error --> Cannot redeclare Requestfeedback_model::get_company_list() D:\xampp\htdocs\orgchart\application\models\Requestfeedback_model.php 46
ERROR - 2020-08-25 08:31:05 --> Query error: Unknown column 'first_name' in 'where clause' - Invalid query: select reqfd_id from requestfdbck_master  where first_name Like '%k%' and is_delete=0
ERROR - 2020-08-25 11:02:34 --> Severity: Notice --> Undefined index: reqfd_id D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 48
ERROR - 2020-08-25 11:02:34 --> Severity: Notice --> Undefined index: reqfd_userto D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 49
ERROR - 2020-08-25 11:02:34 --> Severity: Notice --> Undefined index: reqfd_userfrom D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 50
ERROR - 2020-08-25 11:02:34 --> Severity: Notice --> Undefined index: reqfd_status D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 66
ERROR - 2020-08-25 11:02:34 --> Severity: Notice --> Undefined variable: reqfdfromfname D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 69
ERROR - 2020-08-25 11:02:34 --> Severity: Notice --> Undefined index: reqfd_subject D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 70
ERROR - 2020-08-25 11:02:34 --> Severity: Notice --> Undefined index: reqfd_message D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 71
ERROR - 2020-08-25 11:02:34 --> Severity: Notice --> Undefined variable: reqfdtofname D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 72
ERROR - 2020-08-25 11:02:34 --> Severity: Notice --> Undefined index: reqfd_status D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 73
ERROR - 2020-08-25 11:02:34 --> Severity: Notice --> Undefined index: reqfd_status D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 73
ERROR - 2020-08-25 11:02:34 --> Severity: Notice --> Undefined index: reqfd_id D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 76
ERROR - 2020-08-25 11:02:34 --> Severity: Notice --> Undefined index: reqfd_id D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 78
ERROR - 2020-08-25 11:02:34 --> Severity: Notice --> Undefined index: reqfd_id D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 79
ERROR - 2020-08-25 11:02:34 --> Severity: Notice --> Undefined index: reqfd_id D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 80
ERROR - 2020-08-25 11:02:34 --> Severity: Notice --> Undefined index: reqfd_id D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 48
ERROR - 2020-08-25 11:02:34 --> Severity: Notice --> Undefined index: reqfd_userto D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 49
ERROR - 2020-08-25 11:02:34 --> Severity: Notice --> Undefined index: reqfd_userfrom D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 50
ERROR - 2020-08-25 11:02:34 --> Severity: Notice --> Undefined index: reqfd_status D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 66
ERROR - 2020-08-25 11:02:34 --> Severity: Notice --> Undefined variable: reqfdfromfname D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 69
ERROR - 2020-08-25 11:02:34 --> Severity: Notice --> Undefined index: reqfd_subject D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 70
ERROR - 2020-08-25 11:02:34 --> Severity: Notice --> Undefined index: reqfd_message D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 71
ERROR - 2020-08-25 11:02:34 --> Severity: Notice --> Undefined variable: reqfdtofname D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 72
ERROR - 2020-08-25 11:02:34 --> Severity: Notice --> Undefined index: reqfd_status D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 73
ERROR - 2020-08-25 11:02:34 --> Severity: Notice --> Undefined index: reqfd_status D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 73
ERROR - 2020-08-25 11:02:34 --> Severity: Notice --> Undefined index: reqfd_id D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 76
ERROR - 2020-08-25 11:02:34 --> Severity: Notice --> Undefined index: reqfd_id D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 78
ERROR - 2020-08-25 11:02:34 --> Severity: Notice --> Undefined index: reqfd_id D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 79
ERROR - 2020-08-25 11:02:34 --> Severity: Notice --> Undefined index: reqfd_id D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 80
ERROR - 2020-08-25 11:02:34 --> Severity: Notice --> Undefined index: reqfd_id D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 48
ERROR - 2020-08-25 11:02:34 --> Severity: Notice --> Undefined index: reqfd_userto D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 49
ERROR - 2020-08-25 11:02:34 --> Severity: Notice --> Undefined index: reqfd_userfrom D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 50
ERROR - 2020-08-25 11:02:34 --> Severity: Notice --> Undefined index: reqfd_status D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 66
ERROR - 2020-08-25 11:02:35 --> Severity: Notice --> Undefined variable: reqfdfromfname D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 69
ERROR - 2020-08-25 11:02:35 --> Severity: Notice --> Undefined index: reqfd_subject D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 70
ERROR - 2020-08-25 11:02:35 --> Severity: Notice --> Undefined index: reqfd_message D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 71
ERROR - 2020-08-25 11:02:35 --> Severity: Notice --> Undefined variable: reqfdtofname D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 72
ERROR - 2020-08-25 11:02:35 --> Severity: Notice --> Undefined index: reqfd_status D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 73
ERROR - 2020-08-25 11:02:35 --> Severity: Notice --> Undefined index: reqfd_status D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 73
ERROR - 2020-08-25 11:02:35 --> Severity: Notice --> Undefined index: reqfd_id D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 76
ERROR - 2020-08-25 11:02:35 --> Severity: Notice --> Undefined index: reqfd_id D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 78
ERROR - 2020-08-25 11:02:35 --> Severity: Notice --> Undefined index: reqfd_id D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 79
ERROR - 2020-08-25 11:02:35 --> Severity: Notice --> Undefined index: reqfd_id D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 80
ERROR - 2020-08-25 11:02:35 --> Severity: Notice --> Undefined index: reqfd_id D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 48
ERROR - 2020-08-25 11:02:35 --> Severity: Notice --> Undefined index: reqfd_userto D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 49
ERROR - 2020-08-25 11:02:35 --> Severity: Notice --> Undefined index: reqfd_userfrom D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 50
ERROR - 2020-08-25 11:02:35 --> Severity: Notice --> Undefined index: reqfd_status D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 66
ERROR - 2020-08-25 11:02:35 --> Severity: Notice --> Undefined variable: reqfdfromfname D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 69
ERROR - 2020-08-25 11:02:35 --> Severity: Notice --> Undefined index: reqfd_subject D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 70
ERROR - 2020-08-25 11:02:35 --> Severity: Notice --> Undefined index: reqfd_message D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 71
ERROR - 2020-08-25 11:02:35 --> Severity: Notice --> Undefined variable: reqfdtofname D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 72
ERROR - 2020-08-25 11:02:35 --> Severity: Notice --> Undefined index: reqfd_status D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 73
ERROR - 2020-08-25 11:02:35 --> Severity: Notice --> Undefined index: reqfd_status D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 73
ERROR - 2020-08-25 11:02:35 --> Severity: Notice --> Undefined index: reqfd_id D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 76
ERROR - 2020-08-25 11:02:35 --> Severity: Notice --> Undefined index: reqfd_id D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 78
ERROR - 2020-08-25 11:02:35 --> Severity: Notice --> Undefined index: reqfd_id D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 79
ERROR - 2020-08-25 11:02:35 --> Severity: Notice --> Undefined index: reqfd_id D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 80
ERROR - 2020-08-25 11:02:35 --> Severity: Notice --> Undefined index: reqfd_id D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 48
ERROR - 2020-08-25 11:02:35 --> Severity: Notice --> Undefined index: reqfd_userto D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 49
ERROR - 2020-08-25 11:02:35 --> Severity: Notice --> Undefined index: reqfd_userfrom D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 50
ERROR - 2020-08-25 11:02:35 --> Severity: Notice --> Undefined index: reqfd_status D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 66
ERROR - 2020-08-25 11:02:35 --> Severity: Notice --> Undefined variable: reqfdfromfname D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 69
ERROR - 2020-08-25 11:02:35 --> Severity: Notice --> Undefined index: reqfd_subject D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 70
ERROR - 2020-08-25 11:02:35 --> Severity: Notice --> Undefined index: reqfd_message D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 71
ERROR - 2020-08-25 11:02:35 --> Severity: Notice --> Undefined variable: reqfdtofname D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 72
ERROR - 2020-08-25 11:02:35 --> Severity: Notice --> Undefined index: reqfd_status D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 73
ERROR - 2020-08-25 11:02:35 --> Severity: Notice --> Undefined index: reqfd_status D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 73
ERROR - 2020-08-25 11:02:35 --> Severity: Notice --> Undefined index: reqfd_id D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 76
ERROR - 2020-08-25 11:02:35 --> Severity: Notice --> Undefined index: reqfd_id D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 78
ERROR - 2020-08-25 11:02:35 --> Severity: Notice --> Undefined index: reqfd_id D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 79
ERROR - 2020-08-25 11:02:35 --> Severity: Notice --> Undefined index: reqfd_id D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 80
ERROR - 2020-08-25 11:02:35 --> Severity: Notice --> Undefined index: reqfd_id D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 48
ERROR - 2020-08-25 11:02:35 --> Severity: Notice --> Undefined index: reqfd_userto D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 49
ERROR - 2020-08-25 11:02:35 --> Severity: Notice --> Undefined index: reqfd_userfrom D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 50
ERROR - 2020-08-25 11:02:35 --> Severity: Notice --> Undefined index: reqfd_status D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 66
ERROR - 2020-08-25 11:02:35 --> Severity: Notice --> Undefined variable: reqfdfromfname D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 69
ERROR - 2020-08-25 11:02:35 --> Severity: Notice --> Undefined index: reqfd_subject D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 70
ERROR - 2020-08-25 11:02:35 --> Severity: Notice --> Undefined index: reqfd_message D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 71
ERROR - 2020-08-25 11:02:35 --> Severity: Notice --> Undefined variable: reqfdtofname D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 72
ERROR - 2020-08-25 11:02:35 --> Severity: Notice --> Undefined index: reqfd_status D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 73
ERROR - 2020-08-25 11:02:35 --> Severity: Notice --> Undefined index: reqfd_status D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 73
ERROR - 2020-08-25 11:02:35 --> Severity: Notice --> Undefined index: reqfd_id D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 76
ERROR - 2020-08-25 11:02:35 --> Severity: Notice --> Undefined index: reqfd_id D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 78
ERROR - 2020-08-25 11:02:35 --> Severity: Notice --> Undefined index: reqfd_id D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 79
ERROR - 2020-08-25 11:02:35 --> Severity: Notice --> Undefined index: reqfd_id D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 80
ERROR - 2020-08-25 11:02:35 --> Severity: Notice --> Undefined index: reqfd_id D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 48
ERROR - 2020-08-25 11:02:35 --> Severity: Notice --> Undefined index: reqfd_userto D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 49
ERROR - 2020-08-25 11:02:35 --> Severity: Notice --> Undefined index: reqfd_userfrom D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 50
ERROR - 2020-08-25 11:02:35 --> Severity: Notice --> Undefined index: reqfd_status D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 66
ERROR - 2020-08-25 11:02:35 --> Severity: Notice --> Undefined variable: reqfdfromfname D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 69
ERROR - 2020-08-25 11:02:35 --> Severity: Notice --> Undefined index: reqfd_subject D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 70
ERROR - 2020-08-25 11:02:35 --> Severity: Notice --> Undefined index: reqfd_message D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 71
ERROR - 2020-08-25 11:02:35 --> Severity: Notice --> Undefined variable: reqfdtofname D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 72
ERROR - 2020-08-25 11:02:35 --> Severity: Notice --> Undefined index: reqfd_status D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 73
ERROR - 2020-08-25 11:02:35 --> Severity: Notice --> Undefined index: reqfd_status D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 73
ERROR - 2020-08-25 11:02:35 --> Severity: Notice --> Undefined index: reqfd_id D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 76
ERROR - 2020-08-25 11:02:35 --> Severity: Notice --> Undefined index: reqfd_id D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 78
ERROR - 2020-08-25 11:02:35 --> Severity: Notice --> Undefined index: reqfd_id D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 79
ERROR - 2020-08-25 11:02:35 --> Severity: Notice --> Undefined index: reqfd_id D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 80
ERROR - 2020-08-25 11:02:35 --> Severity: Notice --> Undefined index: reqfd_id D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 48
ERROR - 2020-08-25 11:02:35 --> Severity: Notice --> Undefined index: reqfd_userto D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 49
ERROR - 2020-08-25 11:02:35 --> Severity: Notice --> Undefined index: reqfd_userfrom D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 50
ERROR - 2020-08-25 11:02:35 --> Severity: Notice --> Undefined index: reqfd_status D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 66
ERROR - 2020-08-25 11:02:35 --> Severity: Notice --> Undefined variable: reqfdfromfname D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 69
ERROR - 2020-08-25 11:02:35 --> Severity: Notice --> Undefined index: reqfd_subject D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 70
ERROR - 2020-08-25 11:02:35 --> Severity: Notice --> Undefined index: reqfd_message D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 71
ERROR - 2020-08-25 11:02:35 --> Severity: Notice --> Undefined variable: reqfdtofname D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 72
ERROR - 2020-08-25 11:02:35 --> Severity: Notice --> Undefined index: reqfd_status D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 73
ERROR - 2020-08-25 11:02:35 --> Severity: Notice --> Undefined index: reqfd_status D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 73
ERROR - 2020-08-25 11:02:35 --> Severity: Notice --> Undefined index: reqfd_id D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 76
ERROR - 2020-08-25 11:02:35 --> Severity: Notice --> Undefined index: reqfd_id D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 78
ERROR - 2020-08-25 11:02:35 --> Severity: Notice --> Undefined index: reqfd_id D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 79
ERROR - 2020-08-25 11:02:35 --> Severity: Notice --> Undefined index: reqfd_id D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 80
ERROR - 2020-08-25 11:02:35 --> Severity: Notice --> Undefined index: reqfd_id D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 48
ERROR - 2020-08-25 11:02:35 --> Severity: Notice --> Undefined index: reqfd_userto D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 49
ERROR - 2020-08-25 11:02:35 --> Severity: Notice --> Undefined index: reqfd_userfrom D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 50
ERROR - 2020-08-25 11:02:35 --> Severity: Notice --> Undefined index: reqfd_status D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 66
ERROR - 2020-08-25 11:02:35 --> Severity: Notice --> Undefined variable: reqfdfromfname D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 69
ERROR - 2020-08-25 11:02:35 --> Severity: Notice --> Undefined index: reqfd_subject D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 70
ERROR - 2020-08-25 11:02:35 --> Severity: Notice --> Undefined index: reqfd_message D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 71
ERROR - 2020-08-25 11:02:35 --> Severity: Notice --> Undefined variable: reqfdtofname D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 72
ERROR - 2020-08-25 11:02:35 --> Severity: Notice --> Undefined index: reqfd_status D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 73
ERROR - 2020-08-25 11:02:35 --> Severity: Notice --> Undefined index: reqfd_status D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 73
ERROR - 2020-08-25 11:02:35 --> Severity: Notice --> Undefined index: reqfd_id D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 76
ERROR - 2020-08-25 11:02:35 --> Severity: Notice --> Undefined index: reqfd_id D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 78
ERROR - 2020-08-25 11:02:35 --> Severity: Notice --> Undefined index: reqfd_id D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 79
ERROR - 2020-08-25 11:02:35 --> Severity: Notice --> Undefined index: reqfd_id D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 80
ERROR - 2020-08-25 11:02:35 --> Severity: Notice --> Undefined index: reqfd_id D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 48
ERROR - 2020-08-25 11:02:35 --> Severity: Notice --> Undefined index: reqfd_userto D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 49
ERROR - 2020-08-25 11:02:35 --> Severity: Notice --> Undefined index: reqfd_userfrom D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 50
ERROR - 2020-08-25 11:02:35 --> Severity: Notice --> Undefined index: reqfd_status D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 66
ERROR - 2020-08-25 11:02:35 --> Severity: Notice --> Undefined variable: reqfdfromfname D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 69
ERROR - 2020-08-25 11:02:35 --> Severity: Notice --> Undefined index: reqfd_subject D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 70
ERROR - 2020-08-25 11:02:35 --> Severity: Notice --> Undefined index: reqfd_message D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 71
ERROR - 2020-08-25 11:02:35 --> Severity: Notice --> Undefined variable: reqfdtofname D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 72
ERROR - 2020-08-25 11:02:35 --> Severity: Notice --> Undefined index: reqfd_status D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 73
ERROR - 2020-08-25 11:02:35 --> Severity: Notice --> Undefined index: reqfd_status D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 73
ERROR - 2020-08-25 11:02:35 --> Severity: Notice --> Undefined index: reqfd_id D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 76
ERROR - 2020-08-25 11:02:35 --> Severity: Notice --> Undefined index: reqfd_id D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 78
ERROR - 2020-08-25 11:02:35 --> Severity: Notice --> Undefined index: reqfd_id D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 79
ERROR - 2020-08-25 11:02:35 --> Severity: Notice --> Undefined index: reqfd_id D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 80
ERROR - 2020-08-25 11:03:28 --> Severity: Notice --> Undefined index: reqfd_id D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 48
ERROR - 2020-08-25 11:03:28 --> Severity: Notice --> Undefined index: reqfd_userto D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 49
ERROR - 2020-08-25 11:03:28 --> Severity: Notice --> Undefined index: reqfd_userfrom D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 50
ERROR - 2020-08-25 11:03:28 --> Severity: Notice --> Undefined index: reqfd_status D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 66
ERROR - 2020-08-25 11:03:28 --> Severity: Notice --> Undefined variable: reqfdfromfname D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 69
ERROR - 2020-08-25 11:03:29 --> Severity: Notice --> Undefined index: reqfd_subject D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 70
ERROR - 2020-08-25 11:03:29 --> Severity: Notice --> Undefined index: reqfd_message D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 71
ERROR - 2020-08-25 11:03:29 --> Severity: Notice --> Undefined variable: reqfdtofname D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 72
ERROR - 2020-08-25 11:03:29 --> Severity: Notice --> Undefined index: reqfd_status D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 73
ERROR - 2020-08-25 11:03:29 --> Severity: Notice --> Undefined index: reqfd_status D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 73
ERROR - 2020-08-25 11:03:29 --> Severity: Notice --> Undefined index: reqfd_id D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 76
ERROR - 2020-08-25 11:03:29 --> Severity: Notice --> Undefined index: reqfd_id D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 78
ERROR - 2020-08-25 11:03:29 --> Severity: Notice --> Undefined index: reqfd_id D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 79
ERROR - 2020-08-25 11:03:29 --> Severity: Notice --> Undefined index: reqfd_id D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 80
ERROR - 2020-08-25 11:03:29 --> Severity: Notice --> Undefined index: reqfd_id D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 48
ERROR - 2020-08-25 11:03:29 --> Severity: Notice --> Undefined index: reqfd_userto D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 49
ERROR - 2020-08-25 11:03:29 --> Severity: Notice --> Undefined index: reqfd_userfrom D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 50
ERROR - 2020-08-25 11:03:29 --> Severity: Notice --> Undefined index: reqfd_status D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 66
ERROR - 2020-08-25 11:03:29 --> Severity: Notice --> Undefined variable: reqfdfromfname D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 69
ERROR - 2020-08-25 11:03:29 --> Severity: Notice --> Undefined index: reqfd_subject D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 70
ERROR - 2020-08-25 11:03:29 --> Severity: Notice --> Undefined index: reqfd_message D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 71
ERROR - 2020-08-25 11:03:29 --> Severity: Notice --> Undefined variable: reqfdtofname D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 72
ERROR - 2020-08-25 11:03:29 --> Severity: Notice --> Undefined index: reqfd_status D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 73
ERROR - 2020-08-25 11:03:29 --> Severity: Notice --> Undefined index: reqfd_status D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 73
ERROR - 2020-08-25 11:03:29 --> Severity: Notice --> Undefined index: reqfd_id D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 76
ERROR - 2020-08-25 11:03:29 --> Severity: Notice --> Undefined index: reqfd_id D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 78
ERROR - 2020-08-25 11:03:29 --> Severity: Notice --> Undefined index: reqfd_id D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 79
ERROR - 2020-08-25 11:03:29 --> Severity: Notice --> Undefined index: reqfd_id D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 80
ERROR - 2020-08-25 11:03:29 --> Severity: Notice --> Undefined index: reqfd_id D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 48
ERROR - 2020-08-25 11:03:29 --> Severity: Notice --> Undefined index: reqfd_userto D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 49
ERROR - 2020-08-25 11:03:29 --> Severity: Notice --> Undefined index: reqfd_userfrom D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 50
ERROR - 2020-08-25 11:03:29 --> Severity: Notice --> Undefined index: reqfd_status D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 66
ERROR - 2020-08-25 11:03:29 --> Severity: Notice --> Undefined variable: reqfdfromfname D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 69
ERROR - 2020-08-25 11:03:29 --> Severity: Notice --> Undefined index: reqfd_subject D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 70
ERROR - 2020-08-25 11:03:29 --> Severity: Notice --> Undefined index: reqfd_message D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 71
ERROR - 2020-08-25 11:03:29 --> Severity: Notice --> Undefined variable: reqfdtofname D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 72
ERROR - 2020-08-25 11:03:29 --> Severity: Notice --> Undefined index: reqfd_status D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 73
ERROR - 2020-08-25 11:03:29 --> Severity: Notice --> Undefined index: reqfd_status D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 73
ERROR - 2020-08-25 11:03:29 --> Severity: Notice --> Undefined index: reqfd_id D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 76
ERROR - 2020-08-25 11:03:29 --> Severity: Notice --> Undefined index: reqfd_id D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 78
ERROR - 2020-08-25 11:03:29 --> Severity: Notice --> Undefined index: reqfd_id D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 79
ERROR - 2020-08-25 11:03:29 --> Severity: Notice --> Undefined index: reqfd_id D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 80
ERROR - 2020-08-25 11:03:29 --> Severity: Notice --> Undefined index: reqfd_id D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 48
ERROR - 2020-08-25 11:03:29 --> Severity: Notice --> Undefined index: reqfd_userto D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 49
ERROR - 2020-08-25 11:03:29 --> Severity: Notice --> Undefined index: reqfd_userfrom D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 50
ERROR - 2020-08-25 11:03:29 --> Severity: Notice --> Undefined index: reqfd_status D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 66
ERROR - 2020-08-25 11:03:29 --> Severity: Notice --> Undefined variable: reqfdfromfname D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 69
ERROR - 2020-08-25 11:03:29 --> Severity: Notice --> Undefined index: reqfd_subject D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 70
ERROR - 2020-08-25 11:03:29 --> Severity: Notice --> Undefined index: reqfd_message D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 71
ERROR - 2020-08-25 11:03:29 --> Severity: Notice --> Undefined variable: reqfdtofname D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 72
ERROR - 2020-08-25 11:03:29 --> Severity: Notice --> Undefined index: reqfd_status D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 73
ERROR - 2020-08-25 11:03:29 --> Severity: Notice --> Undefined index: reqfd_status D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 73
ERROR - 2020-08-25 11:03:29 --> Severity: Notice --> Undefined index: reqfd_id D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 76
ERROR - 2020-08-25 11:03:29 --> Severity: Notice --> Undefined index: reqfd_id D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 78
ERROR - 2020-08-25 11:03:29 --> Severity: Notice --> Undefined index: reqfd_id D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 79
ERROR - 2020-08-25 11:03:29 --> Severity: Notice --> Undefined index: reqfd_id D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 80
ERROR - 2020-08-25 11:03:29 --> Severity: Notice --> Undefined index: reqfd_id D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 48
ERROR - 2020-08-25 11:03:29 --> Severity: Notice --> Undefined index: reqfd_userto D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 49
ERROR - 2020-08-25 11:03:29 --> Severity: Notice --> Undefined index: reqfd_userfrom D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 50
ERROR - 2020-08-25 11:03:29 --> Severity: Notice --> Undefined index: reqfd_status D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 66
ERROR - 2020-08-25 11:03:29 --> Severity: Notice --> Undefined variable: reqfdfromfname D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 69
ERROR - 2020-08-25 11:03:29 --> Severity: Notice --> Undefined index: reqfd_subject D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 70
ERROR - 2020-08-25 11:03:29 --> Severity: Notice --> Undefined index: reqfd_message D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 71
ERROR - 2020-08-25 11:03:29 --> Severity: Notice --> Undefined variable: reqfdtofname D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 72
ERROR - 2020-08-25 11:03:29 --> Severity: Notice --> Undefined index: reqfd_status D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 73
ERROR - 2020-08-25 11:03:29 --> Severity: Notice --> Undefined index: reqfd_status D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 73
ERROR - 2020-08-25 11:03:29 --> Severity: Notice --> Undefined index: reqfd_id D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 76
ERROR - 2020-08-25 11:03:29 --> Severity: Notice --> Undefined index: reqfd_id D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 78
ERROR - 2020-08-25 11:03:29 --> Severity: Notice --> Undefined index: reqfd_id D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 79
ERROR - 2020-08-25 11:03:29 --> Severity: Notice --> Undefined index: reqfd_id D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 80
ERROR - 2020-08-25 11:03:29 --> Severity: Notice --> Undefined index: reqfd_id D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 48
ERROR - 2020-08-25 11:03:29 --> Severity: Notice --> Undefined index: reqfd_userto D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 49
ERROR - 2020-08-25 11:03:29 --> Severity: Notice --> Undefined index: reqfd_userfrom D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 50
ERROR - 2020-08-25 11:03:29 --> Severity: Notice --> Undefined index: reqfd_status D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 66
ERROR - 2020-08-25 11:03:29 --> Severity: Notice --> Undefined variable: reqfdfromfname D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 69
ERROR - 2020-08-25 11:03:29 --> Severity: Notice --> Undefined index: reqfd_subject D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 70
ERROR - 2020-08-25 11:03:29 --> Severity: Notice --> Undefined index: reqfd_message D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 71
ERROR - 2020-08-25 11:03:29 --> Severity: Notice --> Undefined variable: reqfdtofname D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 72
ERROR - 2020-08-25 11:03:29 --> Severity: Notice --> Undefined index: reqfd_status D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 73
ERROR - 2020-08-25 11:03:29 --> Severity: Notice --> Undefined index: reqfd_status D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 73
ERROR - 2020-08-25 11:03:29 --> Severity: Notice --> Undefined index: reqfd_id D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 76
ERROR - 2020-08-25 11:03:29 --> Severity: Notice --> Undefined index: reqfd_id D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 78
ERROR - 2020-08-25 11:03:29 --> Severity: Notice --> Undefined index: reqfd_id D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 79
ERROR - 2020-08-25 11:03:29 --> Severity: Notice --> Undefined index: reqfd_id D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 80
ERROR - 2020-08-25 11:03:29 --> Severity: Notice --> Undefined index: reqfd_id D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 48
ERROR - 2020-08-25 11:03:29 --> Severity: Notice --> Undefined index: reqfd_userto D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 49
ERROR - 2020-08-25 11:03:29 --> Severity: Notice --> Undefined index: reqfd_userfrom D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 50
ERROR - 2020-08-25 11:03:29 --> Severity: Notice --> Undefined index: reqfd_status D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 66
ERROR - 2020-08-25 11:03:29 --> Severity: Notice --> Undefined variable: reqfdfromfname D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 69
ERROR - 2020-08-25 11:03:29 --> Severity: Notice --> Undefined index: reqfd_subject D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 70
ERROR - 2020-08-25 11:03:29 --> Severity: Notice --> Undefined index: reqfd_message D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 71
ERROR - 2020-08-25 11:03:29 --> Severity: Notice --> Undefined variable: reqfdtofname D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 72
ERROR - 2020-08-25 11:03:29 --> Severity: Notice --> Undefined index: reqfd_status D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 73
ERROR - 2020-08-25 11:03:29 --> Severity: Notice --> Undefined index: reqfd_status D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 73
ERROR - 2020-08-25 11:03:29 --> Severity: Notice --> Undefined index: reqfd_id D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 76
ERROR - 2020-08-25 11:03:29 --> Severity: Notice --> Undefined index: reqfd_id D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 78
ERROR - 2020-08-25 11:03:29 --> Severity: Notice --> Undefined index: reqfd_id D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 79
ERROR - 2020-08-25 11:03:29 --> Severity: Notice --> Undefined index: reqfd_id D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 80
ERROR - 2020-08-25 11:03:29 --> Severity: Notice --> Undefined index: reqfd_id D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 48
ERROR - 2020-08-25 11:03:29 --> Severity: Notice --> Undefined index: reqfd_userto D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 49
ERROR - 2020-08-25 11:03:29 --> Severity: Notice --> Undefined index: reqfd_userfrom D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 50
ERROR - 2020-08-25 11:03:29 --> Severity: Notice --> Undefined index: reqfd_status D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 66
ERROR - 2020-08-25 11:03:29 --> Severity: Notice --> Undefined variable: reqfdfromfname D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 69
ERROR - 2020-08-25 11:03:29 --> Severity: Notice --> Undefined index: reqfd_subject D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 70
ERROR - 2020-08-25 11:03:29 --> Severity: Notice --> Undefined index: reqfd_message D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 71
ERROR - 2020-08-25 11:03:29 --> Severity: Notice --> Undefined variable: reqfdtofname D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 72
ERROR - 2020-08-25 11:03:29 --> Severity: Notice --> Undefined index: reqfd_status D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 73
ERROR - 2020-08-25 11:03:29 --> Severity: Notice --> Undefined index: reqfd_status D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 73
ERROR - 2020-08-25 11:03:29 --> Severity: Notice --> Undefined index: reqfd_id D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 76
ERROR - 2020-08-25 11:03:29 --> Severity: Notice --> Undefined index: reqfd_id D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 78
ERROR - 2020-08-25 11:03:29 --> Severity: Notice --> Undefined index: reqfd_id D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 79
ERROR - 2020-08-25 11:03:29 --> Severity: Notice --> Undefined index: reqfd_id D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 80
ERROR - 2020-08-25 11:03:29 --> Severity: Notice --> Undefined index: reqfd_id D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 48
ERROR - 2020-08-25 11:03:29 --> Severity: Notice --> Undefined index: reqfd_userto D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 49
ERROR - 2020-08-25 11:03:29 --> Severity: Notice --> Undefined index: reqfd_userfrom D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 50
ERROR - 2020-08-25 11:03:29 --> Severity: Notice --> Undefined index: reqfd_status D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 66
ERROR - 2020-08-25 11:03:29 --> Severity: Notice --> Undefined variable: reqfdfromfname D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 69
ERROR - 2020-08-25 11:03:29 --> Severity: Notice --> Undefined index: reqfd_subject D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 70
ERROR - 2020-08-25 11:03:29 --> Severity: Notice --> Undefined index: reqfd_message D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 71
ERROR - 2020-08-25 11:03:29 --> Severity: Notice --> Undefined variable: reqfdtofname D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 72
ERROR - 2020-08-25 11:03:29 --> Severity: Notice --> Undefined index: reqfd_status D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 73
ERROR - 2020-08-25 11:03:29 --> Severity: Notice --> Undefined index: reqfd_status D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 73
ERROR - 2020-08-25 11:03:29 --> Severity: Notice --> Undefined index: reqfd_id D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 76
ERROR - 2020-08-25 11:03:29 --> Severity: Notice --> Undefined index: reqfd_id D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 78
ERROR - 2020-08-25 11:03:29 --> Severity: Notice --> Undefined index: reqfd_id D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 79
ERROR - 2020-08-25 11:03:29 --> Severity: Notice --> Undefined index: reqfd_id D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 80
ERROR - 2020-08-25 11:03:29 --> Severity: Notice --> Undefined index: reqfd_id D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 48
ERROR - 2020-08-25 11:03:29 --> Severity: Notice --> Undefined index: reqfd_userto D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 49
ERROR - 2020-08-25 11:03:29 --> Severity: Notice --> Undefined index: reqfd_userfrom D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 50
ERROR - 2020-08-25 11:03:29 --> Severity: Notice --> Undefined index: reqfd_status D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 66
ERROR - 2020-08-25 11:03:29 --> Severity: Notice --> Undefined variable: reqfdfromfname D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 69
ERROR - 2020-08-25 11:03:29 --> Severity: Notice --> Undefined index: reqfd_subject D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 70
ERROR - 2020-08-25 11:03:29 --> Severity: Notice --> Undefined index: reqfd_message D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 71
ERROR - 2020-08-25 11:03:29 --> Severity: Notice --> Undefined variable: reqfdtofname D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 72
ERROR - 2020-08-25 11:03:29 --> Severity: Notice --> Undefined index: reqfd_status D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 73
ERROR - 2020-08-25 11:03:29 --> Severity: Notice --> Undefined index: reqfd_status D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 73
ERROR - 2020-08-25 11:03:29 --> Severity: Notice --> Undefined index: reqfd_id D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 76
ERROR - 2020-08-25 11:03:29 --> Severity: Notice --> Undefined index: reqfd_id D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 78
ERROR - 2020-08-25 11:03:29 --> Severity: Notice --> Undefined index: reqfd_id D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 79
ERROR - 2020-08-25 11:03:29 --> Severity: Notice --> Undefined index: reqfd_id D:\xampp\htdocs\orgchart\application\views\admin\feedback\requestfeedback_list.php 80
ERROR - 2020-08-25 12:19:13 --> Query error: Unknown column 'rumfrom.first_name' in 'where clause' - Invalid query: select reqfd_id from requestfdbck_master  where rumfrom.first_name like '%k%' or umto.first_name like '%k%' or reqfd_subject Like '%k%' or reqfd_message Like '%k%' 
ERROR - 2020-08-25 12:20:19 --> Query error: Unknown column 'rumfrom.first_name' in 'where clause' - Invalid query: select reqfd_id from requestfdbck_master  where rumfrom.first_name like '%k%' or umto.first_name like '%k%' or reqfd_subject Like '%k%' or reqfd_message Like '%k%' 
ERROR - 2020-08-25 12:21:14 --> Query error: Unknown column 'umfrom.first_name' in 'where clause' - Invalid query: select reqfd_id from requestfdbck_master  where umfrom.first_name like '%k%' or umto.first_name like '%k%' or reqfd_subject Like '%k%' or reqfd_message Like '%k%' 
ERROR - 2020-08-25 12:25:03 --> Query error: Unknown column 'umfrom.first_name' in 'where clause' - Invalid query: select reqfd_id from requestfdbck_master  where umfrom.first_name like '%k%' or umto.first_name like '%k%' or reqfd_subject Like '%k%' or reqfd_message Like '%k%' 
ERROR - 2020-08-25 12:25:20 --> Query error: Unknown column 'umfrom.first_name' in 'where clause' - Invalid query: select reqfd_id from requestfdbck_master  where umfrom.first_name like '%k%' or umto.first_name like '%k%' or reqfd_subject Like '%k%' or reqfd_message Like '%k%' 
ERROR - 2020-08-25 12:26:11 --> Query error: Unknown column 'umfrom.first_name' in 'field list' - Invalid query: select reqfd_id,umfrom.first_name as reqfd_userfrom,reqfd_subject,reqfd_message,umto.first_name as reqfd_userto,reqfd_status,company_id from requestfdbck_master  
ERROR - 2020-08-25 12:26:13 --> Query error: Unknown column 'umfrom.first_name' in 'field list' - Invalid query: select reqfd_id,umfrom.first_name as reqfd_userfrom,reqfd_subject,reqfd_message,umto.first_name as reqfd_userto,reqfd_status,company_id from requestfdbck_master  
ERROR - 2020-08-25 12:26:16 --> Query error: Unknown column 'umfrom.first_name' in 'field list' - Invalid query: select reqfd_id,umfrom.first_name as reqfd_userfrom,reqfd_subject,reqfd_message,umto.first_name as reqfd_userto,reqfd_status,company_id from requestfdbck_master  
ERROR - 2020-08-25 12:26:19 --> Query error: Unknown column 'umfrom.first_name' in 'field list' - Invalid query: select reqfd_id,umfrom.first_name as reqfd_userfrom,reqfd_subject,reqfd_message,umto.first_name as reqfd_userto,reqfd_status,company_id from requestfdbck_master  
ERROR - 2020-08-25 12:26:19 --> Query error: Unknown column 'umfrom.first_name' in 'field list' - Invalid query: select reqfd_id,umfrom.first_name as reqfd_userfrom,reqfd_subject,reqfd_message,umto.first_name as reqfd_userto,reqfd_status,company_id from requestfdbck_master  
ERROR - 2020-08-25 12:26:20 --> Query error: Unknown column 'umfrom.first_name' in 'field list' - Invalid query: select reqfd_id,umfrom.first_name as reqfd_userfrom,reqfd_subject,reqfd_message,umto.first_name as reqfd_userto,reqfd_status,company_id from requestfdbck_master  
ERROR - 2020-08-25 12:26:20 --> Query error: Unknown column 'umfrom.first_name' in 'field list' - Invalid query: select reqfd_id,umfrom.first_name as reqfd_userfrom,reqfd_subject,reqfd_message,umto.first_name as reqfd_userto,reqfd_status,company_id from requestfdbck_master  
ERROR - 2020-08-25 12:26:20 --> Query error: Unknown column 'umfrom.first_name' in 'field list' - Invalid query: select reqfd_id,umfrom.first_name as reqfd_userfrom,reqfd_subject,reqfd_message,umto.first_name as reqfd_userto,reqfd_status,company_id from requestfdbck_master  
ERROR - 2020-08-25 12:26:21 --> Query error: Unknown column 'umfrom.first_name' in 'field list' - Invalid query: select reqfd_id,umfrom.first_name as reqfd_userfrom,reqfd_subject,reqfd_message,umto.first_name as reqfd_userto,reqfd_status,company_id from requestfdbck_master  
ERROR - 2020-08-25 12:26:23 --> Query error: Unknown column 'umfrom.first_name' in 'field list' - Invalid query: select reqfd_id,umfrom.first_name as reqfd_userfrom,reqfd_subject,reqfd_message,umto.first_name as reqfd_userto,reqfd_status,company_id from requestfdbck_master  
ERROR - 2020-08-25 12:48:36 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'reqfd.reqfd_userfrom=umfrom.id and reqfd.reqfd_userto=umto.id' at line 1 - Invalid query: select reqfd_id from `requestfdbck_master` as reqfd, user_master as umfrom, user_master as umto  reqfd.reqfd_userfrom=umfrom.id and reqfd.reqfd_userto=umto.id
ERROR - 2020-08-25 12:50:12 --> Query error: Unknown column 'reqfd.reqfd_userfrom' in 'where clause' - Invalid query: select reqfd_id from requestfdbck_master  where reqfd.reqfd_userfrom=umfrom.id and reqfd.reqfd_userto=umto.id and umfrom.first_name like '%k%' or umto.first_name like '%k%' or reqfd_subject Like '%k%' or reqfd_message Like '%k%' 
ERROR - 2020-08-25 12:51:53 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '.reqfd_userfrom=umfrom.id and reqfd.reqfd_userto=umto.id' at line 1 - Invalid query: select reqfd_id from requestfdbck_master  reqfd.reqfd_userfrom=umfrom.id and reqfd.reqfd_userto=umto.id 
ERROR - 2020-08-25 12:51:54 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '.reqfd_userfrom=umfrom.id and reqfd.reqfd_userto=umto.id' at line 1 - Invalid query: select reqfd_id from requestfdbck_master  reqfd.reqfd_userfrom=umfrom.id and reqfd.reqfd_userto=umto.id 
ERROR - 2020-08-25 12:51:56 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '.reqfd_userfrom=umfrom.id and reqfd.reqfd_userto=umto.id' at line 1 - Invalid query: select reqfd_id from requestfdbck_master  reqfd.reqfd_userfrom=umfrom.id and reqfd.reqfd_userto=umto.id 
ERROR - 2020-08-25 12:54:28 --> Query error: Unknown column 'umfrom.first_name' in 'field list' - Invalid query: select reqfd_id, umfrom.first_name as reqfd_userfrom,reqfd_subject,reqfd_message,umto.first_name as reqfd_userto,reqfd_status,company_id from requestfdbck_master  
ERROR - 2020-08-25 12:55:25 --> Query error: Unknown column 'umfrom.first_name' in 'field list' - Invalid query: select reqfd_id, umfrom.first_name as reqfd_userfrom,reqfd_subject,reqfd_message,umto.first_name as reqfd_userto,reqfd_status,company_id from requestfdbck_master as reqfd  
ERROR - 2020-08-25 12:56:53 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'reqfd.reqfd_userfrom=umfrom.id and reqfd.reqfd_userto=umto.id' at line 1 - Invalid query: select reqfd_id, umfrom.first_name as reqfd_userfrom,reqfd_subject,reqfd_message,umto.first_name as reqfd_userto,reqfd_status,company_id from requestfdbck_master as reqfd,user_master as umfrom, user_master as umto reqfd.reqfd_userfrom=umfrom.id and reqfd.reqfd_userto=umto.id 
ERROR - 2020-08-25 12:58:08 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\orgchart\application\views\admin\employee\orgchart.php 185
ERROR - 2020-08-25 13:22:06 --> 404 Page Not Found: Requestfeedback/edit
ERROR - 2020-08-25 13:26:26 --> Severity: Notice --> Undefined index: total_requestfeedback D:\xampp\htdocs\orgchart\application\controllers\Requestfeedback.php 41
ERROR - 2020-08-25 13:26:58 --> Severity: Notice --> Undefined index: total_requestfeedback D:\xampp\htdocs\orgchart\application\controllers\Requestfeedback.php 41
ERROR - 2020-08-25 13:26:59 --> Severity: Notice --> Undefined index: total_requestfeedback D:\xampp\htdocs\orgchart\application\controllers\Requestfeedback.php 41
ERROR - 2020-08-25 13:26:59 --> Severity: Notice --> Undefined index: total_requestfeedback D:\xampp\htdocs\orgchart\application\controllers\Requestfeedback.php 41
ERROR - 2020-08-25 13:26:59 --> Severity: Notice --> Undefined index: total_requestfeedback D:\xampp\htdocs\orgchart\application\controllers\Requestfeedback.php 41
ERROR - 2020-08-25 13:26:59 --> Severity: Notice --> Undefined index: total_requestfeedback D:\xampp\htdocs\orgchart\application\controllers\Requestfeedback.php 41
ERROR - 2020-08-25 13:26:59 --> Severity: Notice --> Undefined index: total_requestfeedback D:\xampp\htdocs\orgchart\application\controllers\Requestfeedback.php 41
ERROR - 2020-08-25 13:48:47 --> Severity: error --> Exception: Call to undefined function alert() D:\xampp\htdocs\orgchart\application\views\admin\employee\orgchart.php 165
ERROR - 2020-08-25 13:54:41 --> Severity: Notice --> Undefined index: id D:\xampp\htdocs\orgchart\application\views\admin\feedback\edit_requestfeedback.php 23
ERROR - 2020-08-25 13:54:41 --> Severity: Notice --> Undefined variable: secnond_segment D:\xampp\htdocs\orgchart\application\views\admin\feedback\edit_requestfeedback.php 45
ERROR - 2020-08-25 13:55:52 --> Severity: Notice --> Undefined index: id D:\xampp\htdocs\orgchart\application\views\admin\feedback\edit_requestfeedback.php 23
ERROR - 2020-08-25 13:57:10 --> Severity: Notice --> Undefined index: id D:\xampp\htdocs\orgchart\application\views\admin\feedback\edit_requestfeedback.php 23
ERROR - 2020-08-25 14:09:44 --> Severity: Notice --> Undefined variable: error D:\xampp\htdocs\orgchart\application\controllers\Requestfeedback.php 118
ERROR - 2020-08-25 14:09:44 --> Query error: Unknown column 'employee_id' in 'field list' - Invalid query: UPDATE `requestfdbck_master` SET `reqfd_subject` = 'Enviornmnt Discussion', `reqfd_message` = 'desc environments', `employee_id` = NULL
WHERE `reqfd_id` = '16'
ERROR - 2020-08-25 14:10:19 --> Severity: Notice --> Undefined variable: error D:\xampp\htdocs\orgchart\application\controllers\Requestfeedback.php 118
ERROR - 2020-08-25 14:27:59 --> Severity: Warning --> mb_detect_encoding() expects parameter 1 to be string, object given D:\xampp\htdocs\orgchart\dompdf\src\Dompdf.php 424
ERROR - 2020-08-25 14:27:59 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\orgchart\dompdf\src\Dompdf.php 428
ERROR - 2020-08-25 14:27:59 --> Severity: Warning --> mb_convert_encoding(): Illegal character encoding specified D:\xampp\htdocs\orgchart\dompdf\src\Dompdf.php 428
ERROR - 2020-08-25 14:28:01 --> Severity: Warning --> mb_detect_encoding() expects parameter 1 to be string, object given D:\xampp\htdocs\orgchart\dompdf\src\Dompdf.php 424
ERROR - 2020-08-25 14:28:01 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\orgchart\dompdf\src\Dompdf.php 428
ERROR - 2020-08-25 14:28:01 --> Severity: Warning --> mb_convert_encoding(): Illegal character encoding specified D:\xampp\htdocs\orgchart\dompdf\src\Dompdf.php 428
ERROR - 2020-08-25 14:28:03 --> Severity: Warning --> mb_detect_encoding() expects parameter 1 to be string, object given D:\xampp\htdocs\orgchart\dompdf\src\Dompdf.php 424
ERROR - 2020-08-25 14:28:03 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\orgchart\dompdf\src\Dompdf.php 428
ERROR - 2020-08-25 14:28:03 --> Severity: Warning --> mb_convert_encoding(): Illegal character encoding specified D:\xampp\htdocs\orgchart\dompdf\src\Dompdf.php 428
ERROR - 2020-08-25 14:28:29 --> Severity: Warning --> mb_detect_encoding() expects parameter 1 to be string, object given D:\xampp\htdocs\orgchart\dompdf\src\Dompdf.php 424
ERROR - 2020-08-25 14:28:29 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\orgchart\dompdf\src\Dompdf.php 428
ERROR - 2020-08-25 14:28:29 --> Severity: Warning --> mb_convert_encoding(): Illegal character encoding specified D:\xampp\htdocs\orgchart\dompdf\src\Dompdf.php 428
ERROR - 2020-08-25 14:28:32 --> Severity: Warning --> mb_detect_encoding() expects parameter 1 to be string, object given D:\xampp\htdocs\orgchart\dompdf\src\Dompdf.php 424
ERROR - 2020-08-25 14:28:32 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\orgchart\dompdf\src\Dompdf.php 428
ERROR - 2020-08-25 14:28:32 --> Severity: Warning --> mb_convert_encoding(): Illegal character encoding specified D:\xampp\htdocs\orgchart\dompdf\src\Dompdf.php 428
ERROR - 2020-08-25 14:28:33 --> Severity: Warning --> mb_detect_encoding() expects parameter 1 to be string, object given D:\xampp\htdocs\orgchart\dompdf\src\Dompdf.php 424
ERROR - 2020-08-25 14:28:33 --> Severity: 4096 --> Object of class stdClass could not be converted to string D:\xampp\htdocs\orgchart\dompdf\src\Dompdf.php 428
ERROR - 2020-08-25 14:28:33 --> Severity: Warning --> mb_convert_encoding(): Illegal character encoding specified D:\xampp\htdocs\orgchart\dompdf\src\Dompdf.php 428
ERROR - 2020-08-25 14:33:01 --> Severity: Notice --> Trying to get property 'title' of non-object D:\xampp\htdocs\orgchart\application\views\admin\employee\orgchart.php 163
ERROR - 2020-08-25 14:33:03 --> Severity: Notice --> Trying to get property 'title' of non-object D:\xampp\htdocs\orgchart\application\views\admin\employee\orgchart.php 163
ERROR - 2020-08-25 14:33:08 --> Severity: Notice --> Trying to get property 'title' of non-object D:\xampp\htdocs\orgchart\application\views\admin\employee\orgchart.php 163
ERROR - 2020-08-25 14:33:17 --> Severity: Notice --> Undefined variable: id D:\xampp\htdocs\orgchart\application\controllers\Requestfeedback.php 133
ERROR - 2020-08-25 14:33:20 --> Severity: Notice --> Trying to get property 'title' of non-object D:\xampp\htdocs\orgchart\application\views\admin\employee\orgchart.php 163
ERROR - 2020-08-25 14:33:24 --> Severity: Notice --> Trying to get property 'title' of non-object D:\xampp\htdocs\orgchart\application\views\admin\employee\orgchart.php 163
ERROR - 2020-08-25 14:33:26 --> Severity: Notice --> Trying to get property 'title' of non-object D:\xampp\htdocs\orgchart\application\views\admin\employee\orgchart.php 163
ERROR - 2020-08-25 14:45:46 --> Severity: Warning --> Illegal string offset 'name' D:\xampp\htdocs\orgchart\application\views\admin\employee\orgchart.php 166
ERROR - 2020-08-25 14:45:46 --> Severity: Warning --> Illegal string offset 'title' D:\xampp\htdocs\orgchart\application\views\admin\employee\orgchart.php 166
ERROR - 2020-08-25 14:45:46 --> Severity: Warning --> Illegal string offset 'name' D:\xampp\htdocs\orgchart\application\views\admin\employee\orgchart.php 166
ERROR - 2020-08-25 14:45:46 --> Severity: Warning --> Illegal string offset 'title' D:\xampp\htdocs\orgchart\application\views\admin\employee\orgchart.php 166
ERROR - 2020-08-25 14:45:46 --> Severity: Warning --> Illegal string offset 'name' D:\xampp\htdocs\orgchart\application\views\admin\employee\orgchart.php 166
ERROR - 2020-08-25 14:45:46 --> Severity: Warning --> Illegal string offset 'title' D:\xampp\htdocs\orgchart\application\views\admin\employee\orgchart.php 166
ERROR - 2020-08-25 14:45:46 --> Severity: Warning --> Illegal string offset 'name' D:\xampp\htdocs\orgchart\application\views\admin\employee\orgchart.php 166
ERROR - 2020-08-25 14:45:46 --> Severity: Warning --> Illegal string offset 'title' D:\xampp\htdocs\orgchart\application\views\admin\employee\orgchart.php 166
ERROR - 2020-08-25 14:45:46 --> Severity: error --> Exception: Cannot use object of type stdClass as array D:\xampp\htdocs\orgchart\application\views\admin\employee\orgchart.php 166
ERROR - 2020-08-25 14:45:46 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\xampp\htdocs\orgchart\system\core\Exceptions.php:271) D:\xampp\htdocs\orgchart\system\core\Common.php 570
ERROR - 2020-08-25 14:46:38 --> Severity: error --> Exception: Cannot use object of type stdClass as array D:\xampp\htdocs\orgchart\application\views\admin\employee\orgchart.php 165
ERROR - 2020-08-25 14:51:45 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-25 14:51:49 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-25 14:52:32 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-25 14:52:35 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-25 14:53:10 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\orgchart\application\views\admin\employee\orgchart.php 168
ERROR - 2020-08-25 14:53:11 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\orgchart\application\views\admin\employee\orgchart.php 168
ERROR - 2020-08-25 14:53:20 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-25 14:56:08 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-25 14:57:52 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-25 14:58:22 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-25 15:05:03 --> Severity: error --> Exception: syntax error, unexpected 'exit' (T_EXIT) D:\xampp\htdocs\orgchart\application\controllers\Requestfeedback.php 118
ERROR - 2020-08-25 15:06:14 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-25 15:06:21 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-25 15:06:27 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-25 15:06:54 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-25 15:10:47 --> Severity: error --> Exception: syntax error, unexpected end of file, expecting function (T_FUNCTION) or const (T_CONST) D:\xampp\htdocs\orgchart\application\controllers\Requestfeedback.php 134
ERROR - 2020-08-25 15:11:09 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-25 15:21:43 --> Severity: Notice --> Undefined index: reqfd_apply D:\xampp\htdocs\orgchart\application\views\admin\feedback\edit_requestfeedback.php 38
ERROR - 2020-08-25 15:24:37 --> Severity: Notice --> Undefined variable: error D:\xampp\htdocs\orgchart\application\controllers\Requestfeedback.php 117
ERROR - 2020-08-25 15:25:04 --> Severity: Notice --> Undefined variable: error D:\xampp\htdocs\orgchart\application\controllers\Requestfeedback.php 117
