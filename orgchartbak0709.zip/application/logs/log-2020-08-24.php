<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-08-24 08:20:55 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-24 08:21:08 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-24 08:21:17 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-24 08:21:37 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-24 08:23:13 --> Severity: Warning --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() D:\xampp\htdocs\orgchart\system\libraries\Email.php 1902
ERROR - 2020-08-24 08:23:14 --> Severity: Warning --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() D:\xampp\htdocs\orgchart\system\libraries\Email.php 1902
ERROR - 2020-08-24 09:05:16 --> Severity: Notice --> Undefined variable: edit_department D:\xampp\htdocs\orgchart\application\views\admin\department\add_edit_subteam.php 147
ERROR - 2020-08-24 09:05:21 --> Severity: Warning --> Illegal string offset 'user_id' D:\xampp\htdocs\orgchart\application\views\admin\department\add_edit_department.php 150
ERROR - 2020-08-24 09:05:21 --> Severity: Notice --> Uninitialized string offset: 0 D:\xampp\htdocs\orgchart\application\views\admin\department\add_edit_department.php 150
ERROR - 2020-08-24 09:06:04 --> Severity: Warning --> Illegal string offset 'user_id' D:\xampp\htdocs\orgchart\application\views\admin\department\add_edit_department.php 150
ERROR - 2020-08-24 09:06:04 --> Severity: Notice --> Uninitialized string offset: 0 D:\xampp\htdocs\orgchart\application\views\admin\department\add_edit_department.php 150
ERROR - 2020-08-24 09:06:21 --> Severity: Notice --> Undefined variable: edit_department D:\xampp\htdocs\orgchart\application\views\admin\department\add_edit_subteam.php 147
ERROR - 2020-08-24 09:06:50 --> Severity: Warning --> Illegal string offset 'user_id' D:\xampp\htdocs\orgchart\application\views\admin\department\add_edit_department.php 150
ERROR - 2020-08-24 09:06:50 --> Severity: Notice --> Uninitialized string offset: 0 D:\xampp\htdocs\orgchart\application\views\admin\department\add_edit_department.php 150
ERROR - 2020-08-24 09:28:26 --> Severity: Notice --> Undefined property: Requestfeedback::$department_model D:\xampp\htdocs\orgchart\application\controllers\Requestfeedback.php 33
ERROR - 2020-08-24 09:28:26 --> Severity: error --> Exception: Call to a member function get_company_list() on null D:\xampp\htdocs\orgchart\application\controllers\Requestfeedback.php 33
ERROR - 2020-08-24 09:41:42 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '' at line 1 - Invalid query: SELECT * FROM `user_master` where status=1 and role=3 and company=
ERROR - 2020-08-24 09:42:30 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '' at line 1 - Invalid query: SELECT * FROM `user_master` where status=1 and role=3 and company=
ERROR - 2020-08-24 09:42:30 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '' at line 1 - Invalid query: SELECT * FROM `user_master` where status=1 and role=3 and company=
ERROR - 2020-08-24 09:44:13 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '' at line 1 - Invalid query: SELECT * FROM `user_master` where status=1 and role=3 and company=
ERROR - 2020-08-24 10:19:55 --> Severity: Notice --> Undefined property: Requestfeedback::$department_model D:\xampp\htdocs\orgchart\application\controllers\Requestfeedback.php 42
ERROR - 2020-08-24 10:19:55 --> Severity: error --> Exception: Call to a member function insert() on null D:\xampp\htdocs\orgchart\application\controllers\Requestfeedback.php 42
ERROR - 2020-08-24 10:22:23 --> Query error: Unknown column 'subject' in 'field list' - Invalid query: INSERT INTO `requestfdbck_master` (`subject`, `message`, `company_id`) VALUES ('Leave Application', 'Permission ', '2')
ERROR - 2020-08-24 12:00:41 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '' at line 1 - Invalid query: SELECT * FROM `user_master` where status=1 and role=3 and company=
