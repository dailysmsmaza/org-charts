<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-09-04 23:25:44 --> Severity: Warning --> Illegal string offset 'user_id' /home1/gujjucod/public_html/demo/orgchart/application/views/admin/department/add_edit_department.php 150
ERROR - 2020-09-04 23:25:44 --> Severity: Notice --> Uninitialized string offset: 0 /home1/gujjucod/public_html/demo/orgchart/application/views/admin/department/add_edit_department.php 150
ERROR - 2020-09-04 23:26:15 --> 404 Page Not Found: Karimalik/department
ERROR - 2020-09-04 23:29:44 --> Severity: Warning --> Illegal string offset 'user_id' /home1/gujjucod/public_html/demo/orgchart/application/views/admin/department/add_edit_department.php 150
ERROR - 2020-09-04 23:29:44 --> Severity: Notice --> Uninitialized string offset: 0 /home1/gujjucod/public_html/demo/orgchart/application/views/admin/department/add_edit_department.php 150
ERROR - 2020-09-04 23:30:51 --> Severity: Notice --> Undefined variable: edit_department /home1/gujjucod/public_html/demo/orgchart/application/views/admin/department/add_edit_subteam.php 147
ERROR - 2020-09-04 23:31:27 --> Severity: Notice --> Undefined variable: edit_department /home1/gujjucod/public_html/demo/orgchart/application/views/admin/department/add_edit_subteam.php 147
ERROR - 2020-09-04 23:31:32 --> Severity: Notice --> Undefined variable: edit_department /home1/gujjucod/public_html/demo/orgchart/application/views/admin/department/add_edit_subteam.php 147
ERROR - 2020-09-04 23:32:23 --> Severity: Notice --> Undefined variable: edit_department /home1/gujjucod/public_html/demo/orgchart/application/views/admin/department/add_edit_subteam.php 147
ERROR - 2020-09-04 23:33:01 --> Severity: Notice --> Undefined variable: edit_department /home1/gujjucod/public_html/demo/orgchart/application/views/admin/department/add_edit_subteam.php 147
ERROR - 2020-09-04 23:34:11 --> Severity: Warning --> Illegal string offset 'user_id' /home1/gujjucod/public_html/demo/orgchart/application/views/admin/department/add_edit_department.php 150
ERROR - 2020-09-04 23:34:11 --> Severity: Notice --> Uninitialized string offset: 0 /home1/gujjucod/public_html/demo/orgchart/application/views/admin/department/add_edit_department.php 150
ERROR - 2020-09-04 23:34:57 --> Severity: Notice --> Undefined index: user_id /home1/gujjucod/public_html/demo/orgchart/application/views/admin/department/add_edit_department.php 150
ERROR - 2020-09-04 23:35:11 --> Severity: Notice --> Undefined index: user_id /home1/gujjucod/public_html/demo/orgchart/application/views/admin/department/add_edit_department.php 150
ERROR - 2020-09-04 23:35:34 --> Severity: Notice --> Undefined variable: edit_department /home1/gujjucod/public_html/demo/orgchart/application/views/admin/department/add_edit_subteam.php 147
ERROR - 2020-09-04 23:35:45 --> Severity: Notice --> Undefined variable: edit_department /home1/gujjucod/public_html/demo/orgchart/application/views/admin/department/add_edit_subteam.php 147
ERROR - 2020-09-04 23:36:54 --> Severity: Notice --> Undefined index: user_id /home1/gujjucod/public_html/demo/orgchart/application/views/admin/department/add_edit_department.php 150
