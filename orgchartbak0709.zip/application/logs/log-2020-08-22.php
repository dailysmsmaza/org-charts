<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-08-22 14:59:28 --> Severity: error --> Exception: syntax error, unexpected '>' D:\xampp\htdocs\orgchart\application\views\admin\employee\orgchart.php 146
ERROR - 2020-08-22 14:59:30 --> Severity: error --> Exception: syntax error, unexpected '>' D:\xampp\htdocs\orgchart\application\views\admin\employee\orgchart.php 146
ERROR - 2020-08-22 14:59:32 --> Severity: error --> Exception: syntax error, unexpected '>' D:\xampp\htdocs\orgchart\application\views\admin\employee\orgchart.php 146
ERROR - 2020-08-22 14:59:37 --> Severity: error --> Exception: syntax error, unexpected '>' D:\xampp\htdocs\orgchart\application\views\admin\employee\orgchart.php 146
ERROR - 2020-08-22 15:02:23 --> Severity: error --> Exception: No block-level parent found.  Not good. D:\xampp\htdocs\orgchart\dompdf\src\Positioner\Inline.php 45
ERROR - 2020-08-22 15:03:01 --> Severity: error --> Exception: No block-level parent found.  Not good. D:\xampp\htdocs\orgchart\dompdf\src\Positioner\Inline.php 45
ERROR - 2020-08-22 15:05:29 --> Severity: error --> Exception: No block-level parent found.  Not good. D:\xampp\htdocs\orgchart\dompdf\src\Positioner\Inline.php 45
ERROR - 2020-08-22 15:13:52 --> Severity: Warning --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() D:\xampp\htdocs\orgchart\system\libraries\Email.php 1902
ERROR - 2020-08-22 15:13:53 --> Severity: Warning --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() D:\xampp\htdocs\orgchart\system\libraries\Email.php 1902
