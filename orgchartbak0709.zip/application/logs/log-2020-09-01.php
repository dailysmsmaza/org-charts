<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-09-01 07:43:58 --> 404 Page Not Found: Assets/chart
ERROR - 2020-09-01 07:46:08 --> 404 Page Not Found: Assets/chart
ERROR - 2020-09-01 07:46:20 --> 404 Page Not Found: Assets/chart
ERROR - 2020-09-01 07:46:32 --> 404 Page Not Found: Assets/chart
ERROR - 2020-09-01 07:46:37 --> 404 Page Not Found: Assets/chart
ERROR - 2020-09-01 07:52:00 --> 404 Page Not Found: Assets/chart
ERROR - 2020-09-01 07:52:39 --> 404 Page Not Found: Assets/chart
ERROR - 2020-09-01 07:54:39 --> 404 Page Not Found: Assets/chart
ERROR - 2020-09-01 08:01:54 --> 404 Page Not Found: Assets/chart
ERROR - 2020-09-01 08:02:00 --> 404 Page Not Found: Assets/chart
ERROR - 2020-09-01 08:02:31 --> 404 Page Not Found: Assets/chart
ERROR - 2020-09-01 08:02:33 --> 404 Page Not Found: Assets/chart
ERROR - 2020-09-01 08:02:47 --> 404 Page Not Found: Assets/chart
ERROR - 2020-09-01 08:06:46 --> 404 Page Not Found: Assets/chart
ERROR - 2020-09-01 08:13:58 --> 404 Page Not Found: Assets/chart
