<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-08-27 06:37:35 --> Severity: Notice --> Undefined variable: error D:\xampp\htdocs\orgchart\application\controllers\Requestfeedback.php 170
ERROR - 2020-08-27 08:09:54 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-27 08:44:02 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\orgchart\application\controllers\Requestfeedback.php 147
ERROR - 2020-08-27 08:44:02 --> Severity: Notice --> Array to string conversion D:\xampp\htdocs\orgchart\application\controllers\Requestfeedback.php 147
ERROR - 2020-08-27 09:07:09 --> Severity: Notice --> Undefined variable: error D:\xampp\htdocs\orgchart\application\controllers\Requestfeedback.php 206
ERROR - 2020-08-27 09:07:59 --> Severity: Notice --> Undefined variable: error D:\xampp\htdocs\orgchart\application\controllers\Requestfeedback.php 206
ERROR - 2020-08-27 09:08:08 --> Severity: Notice --> Undefined variable: error D:\xampp\htdocs\orgchart\application\controllers\Requestfeedback.php 206
ERROR - 2020-08-27 09:17:20 --> Severity: Notice --> Undefined variable: error D:\xampp\htdocs\orgchart\application\controllers\Requestfeedback.php 207
ERROR - 2020-08-27 09:17:20 --> Severity: Notice --> Undefined variable: reqfdtoemail D:\xampp\htdocs\orgchart\application\controllers\Requestfeedback.php 220
ERROR - 2020-08-27 09:17:20 --> Severity: Notice --> Undefined index: reqfd_subject D:\xampp\htdocs\orgchart\application\controllers\Requestfeedback.php 222
ERROR - 2020-08-27 09:17:20 --> Severity: Notice --> Undefined variable: reqfdtofirst_name D:\xampp\htdocs\orgchart\application\controllers\Requestfeedback.php 234
ERROR - 2020-08-27 09:17:20 --> Severity: Notice --> Undefined variable: reqfdtolast_name D:\xampp\htdocs\orgchart\application\controllers\Requestfeedback.php 234
ERROR - 2020-08-27 09:17:20 --> Severity: Notice --> Undefined variable: reqfdfromfirst_name D:\xampp\htdocs\orgchart\application\controllers\Requestfeedback.php 238
ERROR - 2020-08-27 09:17:20 --> Severity: Notice --> Undefined variable: reqfdfromlast_name D:\xampp\htdocs\orgchart\application\controllers\Requestfeedback.php 238
ERROR - 2020-08-27 09:17:20 --> Severity: Notice --> Undefined index: reqfd_message D:\xampp\htdocs\orgchart\application\controllers\Requestfeedback.php 239
ERROR - 2020-08-27 09:22:09 --> Severity: Notice --> Undefined variable: error D:\xampp\htdocs\orgchart\application\controllers\Requestfeedback.php 208
ERROR - 2020-08-27 09:23:06 --> Severity: Notice --> Undefined variable: error D:\xampp\htdocs\orgchart\application\controllers\Requestfeedback.php 208
ERROR - 2020-08-27 09:25:13 --> Severity: Notice --> Undefined variable: error D:\xampp\htdocs\orgchart\application\controllers\Requestfeedback.php 208
ERROR - 2020-08-27 09:35:20 --> Severity: Notice --> Undefined variable: error D:\xampp\htdocs\orgchart\application\controllers\Requestfeedback.php 207
ERROR - 2020-08-27 09:35:20 --> Severity: Notice --> Undefined index: reqfd_userfrom D:\xampp\htdocs\orgchart\application\controllers\Requestfeedback.php 220
ERROR - 2020-08-27 09:35:35 --> Severity: Notice --> Undefined variable: error D:\xampp\htdocs\orgchart\application\controllers\Requestfeedback.php 207
ERROR - 2020-08-27 09:35:35 --> Severity: Notice --> Undefined index: reqfd_userfrom D:\xampp\htdocs\orgchart\application\controllers\Requestfeedback.php 220
ERROR - 2020-08-27 09:35:50 --> Severity: Notice --> Undefined variable: error D:\xampp\htdocs\orgchart\application\controllers\Requestfeedback.php 207
ERROR - 2020-08-27 09:35:50 --> Severity: Notice --> Undefined index: reqfd_subject D:\xampp\htdocs\orgchart\application\controllers\Requestfeedback.php 220
ERROR - 2020-08-27 09:35:55 --> Severity: Notice --> Undefined variable: error D:\xampp\htdocs\orgchart\application\controllers\Requestfeedback.php 207
ERROR - 2020-08-27 09:35:55 --> Severity: Notice --> Undefined index: reqfd_subject D:\xampp\htdocs\orgchart\application\controllers\Requestfeedback.php 220
ERROR - 2020-08-27 09:36:24 --> Severity: Notice --> Undefined variable: error D:\xampp\htdocs\orgchart\application\controllers\Requestfeedback.php 207
ERROR - 2020-08-27 09:36:43 --> Severity: Notice --> Undefined variable: error D:\xampp\htdocs\orgchart\application\controllers\Requestfeedback.php 205
ERROR - 2020-08-27 09:36:57 --> Severity: Notice --> Undefined variable: error D:\xampp\htdocs\orgchart\application\controllers\Requestfeedback.php 205
ERROR - 2020-08-27 09:43:32 --> Severity: Notice --> Undefined variable: error D:\xampp\htdocs\orgchart\application\controllers\Requestfeedback.php 209
ERROR - 2020-08-27 09:46:24 --> Severity: Notice --> Undefined variable: reqfd_subject D:\xampp\htdocs\orgchart\application\controllers\Requestfeedback.php 221
ERROR - 2020-08-27 11:11:50 --> Severity: Notice --> Undefined index: reqfd_subject D:\xampp\htdocs\orgchart\application\controllers\Requestfeedback.php 230
ERROR - 2020-08-27 11:12:07 --> Severity: Notice --> Undefined index: reqfd_subject D:\xampp\htdocs\orgchart\application\controllers\Requestfeedback.php 230
ERROR - 2020-08-27 11:13:14 --> Severity: Notice --> Undefined variable: reqfdtoemail D:\xampp\htdocs\orgchart\application\controllers\Requestfeedback.php 234
ERROR - 2020-08-27 11:13:14 --> Severity: Notice --> Undefined variable: reqfdtofirst_name D:\xampp\htdocs\orgchart\application\controllers\Requestfeedback.php 248
ERROR - 2020-08-27 11:13:14 --> Severity: Notice --> Undefined variable: reqfdtolast_name D:\xampp\htdocs\orgchart\application\controllers\Requestfeedback.php 248
ERROR - 2020-08-27 11:15:11 --> Severity: Notice --> Undefined variable: reqfdtoemail D:\xampp\htdocs\orgchart\application\controllers\Requestfeedback.php 234
ERROR - 2020-08-27 11:15:11 --> Severity: Notice --> Undefined index: reqfd_subject D:\xampp\htdocs\orgchart\application\controllers\Requestfeedback.php 236
ERROR - 2020-08-27 11:15:11 --> Severity: Notice --> Undefined variable: reqfdtofirst_name D:\xampp\htdocs\orgchart\application\controllers\Requestfeedback.php 248
ERROR - 2020-08-27 11:15:11 --> Severity: Notice --> Undefined variable: reqfdtolast_name D:\xampp\htdocs\orgchart\application\controllers\Requestfeedback.php 248
ERROR - 2020-08-27 11:15:11 --> Severity: Notice --> Undefined index: reqfd_message D:\xampp\htdocs\orgchart\application\controllers\Requestfeedback.php 253
ERROR - 2020-08-27 11:15:12 --> Severity: Warning --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() D:\xampp\htdocs\orgchart\system\libraries\Email.php 1902
ERROR - 2020-08-27 11:32:59 --> Severity: Notice --> Undefined index: reqfd_subject D:\xampp\htdocs\orgchart\application\controllers\Requestfeedback.php 230
ERROR - 2020-08-27 11:40:20 --> Severity: Notice --> Undefined variable: reqfdtoemail D:\xampp\htdocs\orgchart\application\controllers\Requestfeedback.php 230
ERROR - 2020-08-27 11:47:04 --> Severity: Notice --> Undefined variable: employee_id D:\xampp\htdocs\orgchart\application\controllers\Requestfeedback.php 207
ERROR - 2020-08-27 11:47:04 --> Severity: Notice --> Undefined variable: employee_id D:\xampp\htdocs\orgchart\application\controllers\Requestfeedback.php 221
ERROR - 2020-08-27 11:47:04 --> Severity: Notice --> Undefined variable: reqfdtoemail D:\xampp\htdocs\orgchart\application\controllers\Requestfeedback.php 226
ERROR - 2020-08-27 11:47:49 --> Severity: Notice --> Undefined variable: reqfdtoemail D:\xampp\htdocs\orgchart\application\controllers\Requestfeedback.php 227
ERROR - 2020-08-27 11:48:18 --> Severity: Notice --> Undefined variable: reqfdtoemail D:\xampp\htdocs\orgchart\application\controllers\Requestfeedback.php 227
ERROR - 2020-08-27 11:51:32 --> Query error: Unknown column 'id' in 'where clause' - Invalid query: SELECT * FROM requestfdbck_master WHERE id = 16
ERROR - 2020-08-27 11:52:52 --> Severity: Warning --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() D:\xampp\htdocs\orgchart\system\libraries\Email.php 1902
ERROR - 2020-08-27 11:58:48 --> Severity: Notice --> Undefined index: reqfd_subject D:\xampp\htdocs\orgchart\application\controllers\Requestfeedback.php 233
ERROR - 2020-08-27 11:58:49 --> Severity: Notice --> Undefined index: reqfd_message D:\xampp\htdocs\orgchart\application\controllers\Requestfeedback.php 250
ERROR - 2020-08-27 12:02:09 --> Severity: Notice --> Undefined index: reqfd_subject D:\xampp\htdocs\orgchart\application\controllers\Requestfeedback.php 233
ERROR - 2020-08-27 12:02:09 --> Severity: Notice --> Undefined index: reqfd_subject D:\xampp\htdocs\orgchart\application\controllers\Requestfeedback.php 234
ERROR - 2020-08-27 12:02:09 --> Severity: Notice --> Undefined index: reqfd_message D:\xampp\htdocs\orgchart\application\controllers\Requestfeedback.php 253
ERROR - 2020-08-27 12:02:28 --> Severity: Notice --> Undefined index: reqfd_subject D:\xampp\htdocs\orgchart\application\controllers\Requestfeedback.php 233
ERROR - 2020-08-27 12:02:28 --> Severity: Notice --> Undefined index: reqfd_message D:\xampp\htdocs\orgchart\application\controllers\Requestfeedback.php 253
ERROR - 2020-08-27 12:02:39 --> Severity: Notice --> Undefined index: reqfd_subject D:\xampp\htdocs\orgchart\application\controllers\Requestfeedback.php 233
ERROR - 2020-08-27 12:02:39 --> Severity: Notice --> Undefined index: reqfd_message D:\xampp\htdocs\orgchart\application\controllers\Requestfeedback.php 253
ERROR - 2020-08-27 12:05:06 --> Severity: Notice --> Undefined index: reqfd_subject D:\xampp\htdocs\orgchart\application\controllers\Requestfeedback.php 233
ERROR - 2020-08-27 12:05:06 --> Severity: Notice --> Undefined index: reqfd_message D:\xampp\htdocs\orgchart\application\controllers\Requestfeedback.php 253
ERROR - 2020-08-27 12:09:55 --> Severity: Notice --> Undefined index: reqfd_subject D:\xampp\htdocs\orgchart\application\controllers\Requestfeedback.php 233
ERROR - 2020-08-27 12:09:55 --> Severity: Notice --> Undefined index: reqfd_message D:\xampp\htdocs\orgchart\application\controllers\Requestfeedback.php 253
ERROR - 2020-08-27 12:50:16 --> Severity: Warning --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() D:\xampp\htdocs\orgchart\system\libraries\Email.php 1902
ERROR - 2020-08-27 12:50:29 --> Severity: Warning --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() D:\xampp\htdocs\orgchart\system\libraries\Email.php 1902
ERROR - 2020-08-27 12:52:23 --> Severity: Warning --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() D:\xampp\htdocs\orgchart\system\libraries\Email.php 1902
ERROR - 2020-08-27 12:52:37 --> Severity: Warning --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() D:\xampp\htdocs\orgchart\system\libraries\Email.php 1902
ERROR - 2020-08-27 06:37:38 --> 404 Page Not Found: Assets/userimage
ERROR - 2020-08-27 06:37:38 --> 404 Page Not Found: Assets/userimage
ERROR - 2020-08-27 06:37:38 --> 404 Page Not Found: Assets/userimage
ERROR - 2020-08-27 06:37:38 --> 404 Page Not Found: Assets/userimage
ERROR - 2020-08-27 06:37:38 --> 404 Page Not Found: Assets/userimage
ERROR - 2020-08-27 06:37:38 --> 404 Page Not Found: Assets/userimage
ERROR - 2020-08-27 06:37:38 --> 404 Page Not Found: Assets/userimage
ERROR - 2020-08-27 06:37:38 --> 404 Page Not Found: Assets/userimage
ERROR - 2020-08-27 06:37:38 --> 404 Page Not Found: Assets/userimage
ERROR - 2020-08-27 07:29:00 --> 404 Page Not Found: Assets/userimage
ERROR - 2020-08-27 07:29:00 --> 404 Page Not Found: Assets/userimage
ERROR - 2020-08-27 07:29:00 --> 404 Page Not Found: Assets/userimage
ERROR - 2020-08-27 07:29:00 --> 404 Page Not Found: Assets/userimage
ERROR - 2020-08-27 07:29:00 --> 404 Page Not Found: Assets/userimage
ERROR - 2020-08-27 07:29:00 --> 404 Page Not Found: Assets/userimage
ERROR - 2020-08-27 07:29:00 --> 404 Page Not Found: Assets/userimage
ERROR - 2020-08-27 07:29:00 --> 404 Page Not Found: Assets/userimage
ERROR - 2020-08-27 07:29:00 --> 404 Page Not Found: Assets/userimage
ERROR - 2020-08-27 07:29:37 --> 404 Page Not Found: Assets/userimage
ERROR - 2020-08-27 07:29:37 --> 404 Page Not Found: Assets/userimage
ERROR - 2020-08-27 07:29:37 --> 404 Page Not Found: Assets/userimage
ERROR - 2020-08-27 07:29:37 --> 404 Page Not Found: Assets/userimage
ERROR - 2020-08-27 07:29:37 --> 404 Page Not Found: Assets/userimage
ERROR - 2020-08-27 07:29:37 --> 404 Page Not Found: Assets/userimage
ERROR - 2020-08-27 07:29:37 --> 404 Page Not Found: Assets/userimage
ERROR - 2020-08-27 07:29:38 --> 404 Page Not Found: Assets/userimage
ERROR - 2020-08-27 07:29:38 --> 404 Page Not Found: Assets/userimage
ERROR - 2020-08-27 07:29:41 --> 404 Page Not Found: Assets/userimage
ERROR - 2020-08-27 07:30:23 --> 404 Page Not Found: Assets/userimage
ERROR - 2020-08-27 07:30:27 --> 404 Page Not Found: Assets/userimage
ERROR - 2020-08-27 07:33:13 --> 404 Page Not Found: Assets/chart
ERROR - 2020-08-27 07:33:26 --> 404 Page Not Found: Assets/chart
ERROR - 2020-08-27 07:33:57 --> 404 Page Not Found: Assets/chart
ERROR - 2020-08-27 07:34:46 --> 404 Page Not Found: Assets/chart
ERROR - 2020-08-27 07:38:26 --> 404 Page Not Found: Assets/chart
ERROR - 2020-08-27 07:39:21 --> 404 Page Not Found: Assets/chart
ERROR - 2020-08-27 07:39:32 --> 404 Page Not Found: Assets/chart
ERROR - 2020-08-27 07:42:41 --> 404 Page Not Found: Assets/chart
ERROR - 2020-08-27 07:42:49 --> 404 Page Not Found: Assets/chart
ERROR - 2020-08-27 07:44:20 --> 404 Page Not Found: Assets/chart
ERROR - 2020-08-27 07:44:40 --> 404 Page Not Found: Assets/chart
ERROR - 2020-08-27 07:44:49 --> 404 Page Not Found: Assets/chart
ERROR - 2020-08-27 07:51:57 --> 404 Page Not Found: Assets/front
ERROR - 2020-08-27 08:12:23 --> 404 Page Not Found: Assets/chart
ERROR - 2020-08-27 08:21:16 --> 404 Page Not Found: Assets/chart
