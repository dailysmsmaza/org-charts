<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-09-05 06:21:10 --> Severity: Notice --> Trying to get property of non-object /home1/gujjucod/public_html/demo/orgchart/application/views/admin/employee/orgchart.php 75
ERROR - 2020-09-05 06:21:10 --> Severity: Notice --> Trying to get property of non-object /home1/gujjucod/public_html/demo/orgchart/application/views/admin/employee/orgchart.php 76
ERROR - 2020-09-05 06:21:10 --> Severity: Notice --> Trying to get property of non-object /home1/gujjucod/public_html/demo/orgchart/application/views/admin/employee/orgchart.php 76
ERROR - 2020-09-05 06:21:10 --> Severity: Notice --> Trying to get property of non-object /home1/gujjucod/public_html/demo/orgchart/application/views/admin/employee/orgchart.php 76
ERROR - 2020-09-05 06:21:10 --> Severity: Notice --> Trying to get property of non-object /home1/gujjucod/public_html/demo/orgchart/application/views/admin/employee/orgchart.php 76
ERROR - 2020-09-05 07:53:38 --> 404 Page Not Found: Assets/userimage
ERROR - 2020-09-05 07:53:52 --> 404 Page Not Found: Assets/userimage
ERROR - 2020-09-05 07:54:03 --> 404 Page Not Found: Assets/userimage
ERROR - 2020-09-05 07:54:08 --> 404 Page Not Found: Assets/userimage
ERROR - 2020-09-05 07:54:30 --> 404 Page Not Found: Assets/userimage
ERROR - 2020-09-05 07:54:41 --> 404 Page Not Found: Assets/userimage
ERROR - 2020-09-05 07:54:49 --> 404 Page Not Found: Assets/userimage
ERROR - 2020-09-05 07:55:06 --> 404 Page Not Found: Assets/userimage
ERROR - 2020-09-05 07:55:18 --> 404 Page Not Found: Assets/userimage
ERROR - 2020-09-05 07:55:33 --> 404 Page Not Found: Assets/userimage
ERROR - 2020-09-05 07:55:34 --> 404 Page Not Found: Assets/userimage
ERROR - 2020-09-05 07:55:38 --> 404 Page Not Found: Assets/userimage
ERROR - 2020-09-05 07:55:39 --> 404 Page Not Found: Assets/userimage
ERROR - 2020-09-05 07:56:05 --> 404 Page Not Found: Assets/css
