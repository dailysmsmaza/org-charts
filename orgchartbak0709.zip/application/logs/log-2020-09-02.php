<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-09-02 07:50:56 --> Severity: Notice --> Undefined index: reqfd_createdby /home1/gujjucod/public_html/demo/orgchart/application/views/admin/feedback/requestfeedback_list.php 96
ERROR - 2020-09-02 07:50:56 --> Severity: Notice --> Undefined index: reqfd_createdby /home1/gujjucod/public_html/demo/orgchart/application/views/admin/feedback/requestfeedback_list.php 96
ERROR - 2020-09-02 07:51:06 --> Severity: Notice --> Undefined index: reqfd_createdby /home1/gujjucod/public_html/demo/orgchart/application/views/admin/feedback/requestfeedback_list.php 96
ERROR - 2020-09-02 07:51:06 --> Severity: Notice --> Undefined index: reqfd_createdby /home1/gujjucod/public_html/demo/orgchart/application/views/admin/feedback/requestfeedback_list.php 96
ERROR - 2020-09-02 07:55:07 --> Severity: Notice --> Undefined index: reqfd_createdby /home1/gujjucod/public_html/demo/orgchart/application/views/admin/feedback/requestfeedback_list.php 96
ERROR - 2020-09-02 07:55:07 --> Severity: Notice --> Undefined index: reqfd_createdby /home1/gujjucod/public_html/demo/orgchart/application/views/admin/feedback/requestfeedback_list.php 96
ERROR - 2020-09-02 07:55:13 --> Severity: Notice --> Undefined index: reqfd_createdby /home1/gujjucod/public_html/demo/orgchart/application/views/admin/feedback/requestfeedback_list.php 96
ERROR - 2020-09-02 07:55:13 --> Severity: Notice --> Undefined index: reqfd_createdby /home1/gujjucod/public_html/demo/orgchart/application/views/admin/feedback/requestfeedback_list.php 96
ERROR - 2020-09-02 07:57:12 --> Severity: Notice --> Undefined index: reqfd_createdby /home1/gujjucod/public_html/demo/orgchart/application/views/admin/feedback/requestfeedback_list.php 96
ERROR - 2020-09-02 07:57:12 --> Severity: Notice --> Undefined index: reqfd_createdby /home1/gujjucod/public_html/demo/orgchart/application/views/admin/feedback/requestfeedback_list.php 96
ERROR - 2020-09-02 07:57:12 --> Severity: Notice --> Undefined index: reqfd_createdby /home1/gujjucod/public_html/demo/orgchart/application/views/admin/feedback/requestfeedback_list.php 96
ERROR - 2020-09-02 07:58:47 --> Severity: Notice --> Undefined index: reqfd_createdby /home1/gujjucod/public_html/demo/orgchart/application/views/admin/feedback/requestfeedback_list.php 96
ERROR - 2020-09-02 07:58:47 --> Severity: Notice --> Undefined index: reqfd_createdby /home1/gujjucod/public_html/demo/orgchart/application/views/admin/feedback/requestfeedback_list.php 96
ERROR - 2020-09-02 07:58:47 --> Severity: Notice --> Undefined index: reqfd_createdby /home1/gujjucod/public_html/demo/orgchart/application/views/admin/feedback/requestfeedback_list.php 96
ERROR - 2020-09-02 07:58:49 --> Severity: Notice --> Undefined index: reqfd_createdby /home1/gujjucod/public_html/demo/orgchart/application/views/admin/feedback/requestfeedback_list.php 96
ERROR - 2020-09-02 07:58:49 --> Severity: Notice --> Undefined index: reqfd_createdby /home1/gujjucod/public_html/demo/orgchart/application/views/admin/feedback/requestfeedback_list.php 96
ERROR - 2020-09-02 07:58:49 --> Severity: Notice --> Undefined index: reqfd_createdby /home1/gujjucod/public_html/demo/orgchart/application/views/admin/feedback/requestfeedback_list.php 96
ERROR - 2020-09-02 08:02:22 --> Severity: Notice --> Undefined index: reqfd_createdby /home1/gujjucod/public_html/demo/orgchart/application/views/admin/feedback/requestfeedback_list.php 96
ERROR - 2020-09-02 08:02:22 --> Severity: Notice --> Undefined index: reqfd_createdby /home1/gujjucod/public_html/demo/orgchart/application/views/admin/feedback/requestfeedback_list.php 96
ERROR - 2020-09-02 08:02:22 --> Severity: Notice --> Undefined index: reqfd_createdby /home1/gujjucod/public_html/demo/orgchart/application/views/admin/feedback/requestfeedback_list.php 96
ERROR - 2020-09-02 08:06:17 --> Severity: Notice --> Undefined index: reqfd_createdby /home1/gujjucod/public_html/demo/orgchart/application/views/admin/feedback/requestfeedback_list.php 96
ERROR - 2020-09-02 08:06:17 --> Severity: Notice --> Undefined index: reqfd_createdby /home1/gujjucod/public_html/demo/orgchart/application/views/admin/feedback/requestfeedback_list.php 96
ERROR - 2020-09-02 08:06:17 --> Severity: Notice --> Undefined index: reqfd_createdby /home1/gujjucod/public_html/demo/orgchart/application/views/admin/feedback/requestfeedback_list.php 96
ERROR - 2020-09-02 08:06:20 --> Severity: Notice --> Undefined index: reqfd_createdby /home1/gujjucod/public_html/demo/orgchart/application/views/admin/feedback/requestfeedback_list.php 96
ERROR - 2020-09-02 08:06:20 --> Severity: Notice --> Undefined index: reqfd_createdby /home1/gujjucod/public_html/demo/orgchart/application/views/admin/feedback/requestfeedback_list.php 96
ERROR - 2020-09-02 08:06:20 --> Severity: Notice --> Undefined index: reqfd_createdby /home1/gujjucod/public_html/demo/orgchart/application/views/admin/feedback/requestfeedback_list.php 96
ERROR - 2020-09-02 08:09:36 --> 404 Page Not Found: Assets/front
ERROR - 2020-09-02 08:13:10 --> 404 Page Not Found: Assets/front
ERROR - 2020-09-02 08:27:48 --> 404 Page Not Found: Assets/css
